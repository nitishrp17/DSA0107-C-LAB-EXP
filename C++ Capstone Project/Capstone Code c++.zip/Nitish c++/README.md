# FairFlow

FairFlow is an academic demonstration of equitable water-request triage, capacity-aware tanker allocation, shortest-path routing and simulated deliveries. The frontend is React + Vite. **The app runs without the C++ backend** using browser `localStorage` for accounts, requests, tanker data, settings and tracking state. The C++17/SQLite backend source remains in `backend/` as an optional project component; the running browser app does not call it.

## Run the browser app (no backend required)

From the FairFlow workspace root:

```powershell
npm install
npm run dev
```

Open `http://127.0.0.1:5173`. Select Admin or Operator, choose **Create account**, register an email and password, and then the account is signed in. Admin registration/sign-in also requires PIN `060506`. Operational sample records are preloaded locally; there are no pre-created login accounts. Local browser data survives refreshes in the same browser profile. Clearing site data removes those accounts and records.

## Requirements

Only install these tools if you also want to build the optional native API on Windows:

- Visual Studio 2022 Build Tools with **Desktop development with C++** (MSVC)
- CMake 3.21 or later
- Ninja
- Git
- vcpkg, with `VCPKG_ROOT` set to its checkout directory
- Node.js 20 or later and npm

The backend dependencies are declared in `backend/vcpkg.json`: cpp-httplib, nlohmann-json, SQLite3 and OpenSSL. CMake's manifest mode installs them on configure.

## Optional native backend (PowerShell)

From the FairFlow workspace root:

```powershell
npm install
cmake --preset windows-vcpkg
cmake --build --preset windows-vcpkg
```

Start the API in its own terminal:

```powershell
.\build\fairflow-api.exe
```

The API listens on `http://127.0.0.1:8080` and creates `backend/database/fairflow.sqlite` on first run. Start the frontend in a second terminal:

```powershell
npm run dev
```

Open `http://127.0.0.1:5173`. Vite proxies `/api` requests to the local C++ API. Keep both processes running while using the app.

To choose another local database or API port:

```powershell
$env:FAIRFLOW_DB = 'backend/database/demo.sqlite'
$env:FAIRFLOW_PORT = '8080'
.\build\fairflow-api.exe
```

## Accounts and sign-in

Choose Admin or Operator, then choose **Sign in** or **Create account**. Both roles use a unique email address and a password of at least eight characters. Admin sign-in and registration also require the fixed demonstration PIN `060506`. New accounts are saved in SQLite; registration signs the user in automatically. There are no pre-filled demo accounts. Existing accounts created before this change can continue to sign in with their email and password; the old seeded `admin@fairflow.demo` and `operator@fairflow.demo` demo users are removed at startup.

Passwords are stored as salted PBKDF2-SHA256 hashes and both roles use opaque database-backed bearer sessions. The shared fixed PIN is intentionally for this local academic demonstration only and must not be used as production authentication. Operator navigation is limited to operational views and delivery tracking; administrator routes enforce their role server-side.

## Implemented modules

- Live database counts, activity, demand/status charts, fleet capacity and reports/CSV export.
- Seeded service areas, requests, tanker fleet, and an explicitly illustrative Chennai road graph.
- Area/request/tanker listing, search/filter, registration and administrative deletion; request and area editing API endpoints are present.
- FCFS, nearest-first and fairness-first allocation in C++, with a priority queue, weighted normalized fairness scores and tanker water-capacity limits.
- Dijkstra shortest paths using the weighted SQLite road graph.
- Persisted start, pause and resume delivery simulation, periodically updated by the API process; delivery completion updates request/tanker records.
- System weights/simulation speed, operational-data reset that preserves registered accounts, activity log, role-aware login/registration, responsive Leaflet map and print/CSV report actions.

All location nodes, distances and GPS movement are simulated. The map tiles are from OpenStreetMap; this is not live municipal road, traffic or GPS integration.

## API overview

The C++ server exposes `/api/health`, `/api/auth/login`, `/api/auth/register`, `/api/auth/logout`, `/api/auth/me`, `/api/dashboard/*`, `/api/areas`, `/api/requests`, `/api/tankers`, `/api/allocation/*`, `/api/routes/*`, `/api/tracking/*`, `/api/reports/*`, `/api/activity`, `/api/settings` and `/api/demo/reset`. Authenticated requests use `Authorization: Bearer <token>`.

## Current limitations

- The current development container had Node/npm but no C++ compiler, CMake, or SQLite CLI. The React production build was verified here; the native backend could not be compiled or its REST endpoints tested in this environment.
- Allocation comparison is an estimate on the current pending queue, not a persisted replay of three isolated historical dispatches. Average wait and area-level fairness reporting should be treated as demonstration metrics until that evaluation workflow is expanded.
- Tracking persists route progress and delivery state, but does not model turn-by-turn road movement, actual vehicle GPS, traffic, or actual ETA telemetry.
- Area/tanker edit forms, delivery reassignment, date-range filters, monthly analytics, and detailed score explanations are not complete in the current UI/API workflow.
- The Leaflet basemap requires an internet connection. If unavailable, the simulated graph and node records remain in the database, but map tiles will not load.

## Troubleshooting

- `cmake` or the C++ compiler is not found: install the Visual Studio C++ workload and CMake/Ninja, then open a fresh Developer PowerShell.
- vcpkg manifest dependencies are not found: verify `$env:VCPKG_ROOT` points at the vcpkg checkout and rerun `cmake --preset windows-vcpkg`.
- The login screen cannot connect: start `fairflow-api.exe` first and check `http://127.0.0.1:8080/api/health`.
- Port 8080 is occupied: set `FAIRFLOW_PORT` before starting the API and update the `/api` proxy target in `vite.config.js` to match.
- Restore the starter dataset from **System settings → Reset demonstration data** (administrator only).
