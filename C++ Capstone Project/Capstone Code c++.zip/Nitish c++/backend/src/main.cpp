#include <httplib.h>
#include <nlohmann/json.hpp>
#include <sqlite3.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/crypto.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <map>
#include <mutex>
#include <queue>
#include <random>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

using json = nlohmann::json;
using namespace std::chrono;

namespace {

class Database {
public:
    sqlite3* handle = nullptr;
    std::recursive_mutex mutex;

    explicit Database(const std::string& path) {
        std::filesystem::create_directories(std::filesystem::path(path).parent_path());
        if (sqlite3_open(path.c_str(), &handle) != SQLITE_OK) throw std::runtime_error(sqlite3_errmsg(handle));
        sqlite3_exec(handle, "PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;", nullptr, nullptr, nullptr);
    }

    ~Database() { if (handle) sqlite3_close(handle); }

    void execute(const std::string& sql, const std::vector<std::string>& values = {}) {
        std::lock_guard<std::recursive_mutex> lock(mutex);
        if (values.empty()) {
            char* error = nullptr;
            if (sqlite3_exec(handle, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
                const std::string message = error ? error : sqlite3_errmsg(handle);
                sqlite3_free(error);
                throw std::runtime_error(message);
            }
            return;
        }
        sqlite3_stmt* statement = nullptr;
        if (sqlite3_prepare_v2(handle, sql.c_str(), -1, &statement, nullptr) != SQLITE_OK) throw std::runtime_error(sqlite3_errmsg(handle));
        for (size_t i = 0; i < values.size(); ++i) sqlite3_bind_text(statement, static_cast<int>(i + 1), values[i].c_str(), -1, SQLITE_TRANSIENT);
        const int result = sqlite3_step(statement);
        if (result != SQLITE_DONE && result != SQLITE_ROW) {
            const std::string error = sqlite3_errmsg(handle);
            sqlite3_finalize(statement);
            throw std::runtime_error(error);
        }
        sqlite3_finalize(statement);
    }

    json rows(const std::string& sql, const std::vector<std::string>& values = {}) {
        std::lock_guard<std::recursive_mutex> lock(mutex);
        sqlite3_stmt* statement = nullptr;
        if (sqlite3_prepare_v2(handle, sql.c_str(), -1, &statement, nullptr) != SQLITE_OK) throw std::runtime_error(sqlite3_errmsg(handle));
        for (size_t i = 0; i < values.size(); ++i) sqlite3_bind_text(statement, static_cast<int>(i + 1), values[i].c_str(), -1, SQLITE_TRANSIENT);
        json result = json::array();
        while (sqlite3_step(statement) == SQLITE_ROW) {
            json item = json::object();
            for (int i = 0; i < sqlite3_column_count(statement); ++i) {
                const char* name = sqlite3_column_name(statement, i);
                switch (sqlite3_column_type(statement, i)) {
                    case SQLITE_INTEGER: item[name] = sqlite3_column_int64(statement, i); break;
                    case SQLITE_FLOAT: item[name] = sqlite3_column_double(statement, i); break;
                    case SQLITE_NULL: item[name] = nullptr; break;
                    default: item[name] = reinterpret_cast<const char*>(sqlite3_column_text(statement, i));
                }
            }
            result.push_back(std::move(item));
        }
        sqlite3_finalize(statement);
        return result;
    }

    json first(const std::string& sql, const std::vector<std::string>& values = {}) {
        auto result = rows(sql, values);
        return result.empty() ? json::object() : result.front();
    }
};

std::unique_ptr<Database> db;
std::atomic<bool> trackingOn{true};
std::thread tracker;
const std::string timestamp() {
    const auto now = system_clock::now();
    const std::time_t value = system_clock::to_time_t(now);
    std::tm utc{};
#ifdef _WIN32
    gmtime_s(&utc, &value);
#else
    gmtime_r(&value, &utc);
#endif
    std::ostringstream output;
    output << std::put_time(&utc, "%Y-%m-%dT%H:%M:%SZ");
    return output.str();
}
std::string value(const json& object, const std::string& key, const std::string& fallback = "") {
    if (!object.contains(key) || object[key].is_null()) return fallback;
    return object[key].is_string() ? object[key].get<std::string>() : object[key].dump();
}
std::string urlPath(const httplib::Request& request) { return request.path; }
void sendJson(httplib::Response& response, int status, const json& body) {
    response.status = status;
    response.set_content(body.dump(), "application/json; charset=utf-8");
}
std::string hex(const unsigned char* data, size_t length) {
    std::ostringstream output;
    output << std::hex << std::setfill('0');
    for (size_t i = 0; i < length; ++i) output << std::setw(2) << static_cast<int>(data[i]);
    return output.str();
}
std::time_t parseUtc(const std::string& input) {
    std::tm parsed{};
    std::istringstream stream(input);
    stream >> std::get_time(&parsed, "%Y-%m-%dT%H:%M:%SZ");
    if (stream.fail()) {
        stream.clear();
        stream.str(input);
        stream >> std::get_time(&parsed, "%Y-%m-%d %H:%M:%S");
    }
    if (stream.fail()) return 0;
#ifdef _WIN32
    return _mkgmtime(&parsed);
#else
    return timegm(&parsed);
#endif
}
std::string passwordHash(const std::string& password, const std::string& salt) {
    unsigned char hash[32];
    if (PKCS5_PBKDF2_HMAC(password.c_str(), static_cast<int>(password.size()),
        reinterpret_cast<const unsigned char*>(salt.data()), static_cast<int>(salt.size()), 210000, EVP_sha256(), sizeof(hash), hash) != 1)
        throw std::runtime_error("Password hashing failed");
    return hex(hash, sizeof(hash));
}
std::string randomHex(size_t bytes) {
    std::vector<unsigned char> data(bytes);
    if (RAND_bytes(data.data(), static_cast<int>(data.size())) != 1) throw std::runtime_error("Secure random generation failed");
    return hex(data.data(), data.size());
}
std::string newPasswordHash(const std::string& password) {
    const auto salt = randomHex(16);
    return salt + "$" + passwordHash(password, salt);
}
bool verifyPassword(const std::string& password, const std::string& stored) {
    const auto split = stored.find('$');
    if (split == std::string::npos) return false;
    const auto salt = stored.substr(0, split);
    const auto expected = stored.substr(split + 1);
    const auto actual = passwordHash(password, salt);
    return expected.size() == actual.size() && CRYPTO_memcmp(expected.data(), actual.data(), expected.size()) == 0;
}
void activity(const std::string& kind, const std::string& message) {
    db->execute("INSERT INTO activity_logs(kind,message,created_at) VALUES(?,?,?)", {kind, message, timestamp()});
}

struct Route { double distance = 0; std::vector<std::string> nodes; };
Route shortestPath(const std::string& start, const std::string& destination) {
    auto edges = db->rows("SELECT from_node,to_node,distance_km FROM road_edges");
    std::unordered_map<std::string, std::vector<std::pair<std::string, double>>> graph;
    for (const auto& edge : edges) graph[value(edge,"from_node")].push_back({value(edge,"to_node"), edge["distance_km"].get<double>()});
    using Entry = std::pair<double, std::string>;
    std::priority_queue<Entry, std::vector<Entry>, std::greater<Entry>> queue;
    std::unordered_map<std::string, double> distances;
    std::unordered_map<std::string, std::string> previous;
    distances[start] = 0;
    queue.push({0, start});
    while (!queue.empty()) {
        auto [distance, node] = queue.top(); queue.pop();
        if (distance > distances[node]) continue;
        if (node == destination) break;
        for (const auto& [next, cost] : graph[node]) {
            const double candidate = distance + cost;
            if (!distances.count(next) || candidate < distances[next]) {
                distances[next] = candidate;
                previous[next] = node;
                queue.push({candidate, next});
            }
        }
    }
    if (!distances.count(destination)) throw std::runtime_error("No route connects the selected nodes");
    Route route;
    route.distance = distances[destination];
    for (std::string node = destination; !node.empty(); node = previous.count(node) ? previous[node] : "") route.nodes.push_back(node);
    std::reverse(route.nodes.begin(), route.nodes.end());
    return route;
}

void initializeDatabase() {
    db->execute(R"SQL(
      CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE,email TEXT UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id),created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS areas(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,type TEXT NOT NULL,location TEXT NOT NULL,lat REAL NOT NULL,lng REAL NOT NULL,population INTEGER NOT NULL,vulnerability REAL NOT NULL,contact TEXT NOT NULL,road_node TEXT NOT NULL,created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS water_requests(id INTEGER PRIMARY KEY AUTOINCREMENT,area_id INTEGER NOT NULL REFERENCES areas(id),requested_litres INTEGER NOT NULL,remaining_litres INTEGER NOT NULL,delivered_litres INTEGER NOT NULL DEFAULT 0,urgency TEXT NOT NULL,vulnerability REAL NOT NULL,created_at TEXT NOT NULL,remarks TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Pending');
      CREATE TABLE IF NOT EXISTS tankers(id INTEGER PRIMARY KEY AUTOINCREMENT,vehicle TEXT UNIQUE NOT NULL,size TEXT NOT NULL,capacity INTEGER NOT NULL,current_water INTEGER NOT NULL,driver TEXT NOT NULL,contact TEXT NOT NULL,status TEXT NOT NULL,road_node TEXT NOT NULL,assigned_area_id INTEGER REFERENCES areas(id));
      CREATE TABLE IF NOT EXISTS allocations(id INTEGER PRIMARY KEY AUTOINCREMENT,request_id INTEGER NOT NULL REFERENCES water_requests(id),tanker_id INTEGER NOT NULL REFERENCES tankers(id),amount_litres INTEGER NOT NULL,strategy TEXT NOT NULL,priority_score REAL NOT NULL,created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS deliveries(id INTEGER PRIMARY KEY AUTOINCREMENT,allocation_id INTEGER NOT NULL REFERENCES allocations(id),request_id INTEGER NOT NULL REFERENCES water_requests(id),tanker_id INTEGER NOT NULL REFERENCES tankers(id),amount_litres INTEGER NOT NULL,distance_km REAL NOT NULL,route_json TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'Pending',created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS simulation_states(delivery_id INTEGER PRIMARY KEY REFERENCES deliveries(id),progress REAL NOT NULL DEFAULT 0,status TEXT NOT NULL DEFAULT 'Pending',updated_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS road_nodes(id TEXT PRIMARY KEY,name TEXT NOT NULL,lat REAL NOT NULL,lng REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS road_edges(id INTEGER PRIMARY KEY AUTOINCREMENT,from_node TEXT NOT NULL REFERENCES road_nodes(id),to_node TEXT NOT NULL REFERENCES road_nodes(id),distance_km REAL NOT NULL);
      CREATE TABLE IF NOT EXISTS activity_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,message TEXT NOT NULL,created_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    )SQL");
    db->execute("DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE email IN ('admin@fairflow.demo','operator@fairflow.demo'))");
    db->execute("DELETE FROM users WHERE email IN ('admin@fairflow.demo','operator@fairflow.demo')");
    if (db->first("SELECT id FROM road_nodes LIMIT 1").empty()) {
        const std::vector<std::tuple<std::string,std::string,double,double>> nodes = {
            {"anna","Anna Nagar",13.0850,80.2101},{"ambattur","Ambattur",13.1143,80.1548},{"kilpauk","Kilpauk",13.0827,80.2380},
            {"egmore","Egmore",13.0732,80.2609},{"perambur","Perambur",13.1161,80.2336},{"tnagar","T. Nagar",13.0418,80.2341},
            {"guindy","Guindy",13.0067,80.2206},{"adyar","Adyar",13.0012,80.2565},{"velachery","Velachery",12.9750,80.2212},{"tambaram","Tambaram",12.9249,80.1000}
        };
        for (const auto& [id,name,lat,lng] : nodes) db->execute("INSERT INTO road_nodes VALUES(?,?,?,?)",{id,name,std::to_string(lat),std::to_string(lng)});
        const std::vector<std::tuple<std::string,std::string,double>> edges = {
            {"anna","ambattur",8.2},{"anna","kilpauk",5.1},{"ambattur","perambur",9.0},{"kilpauk","perambur",5.2},
            {"kilpauk","egmore",3.6},{"perambur","egmore",6.1},{"egmore","tnagar",6.4},{"tnagar","guindy",5.7},
            {"guindy","adyar",7.5},{"guindy","velachery",5.0},{"adyar","velachery",5.4},{"velachery","tambaram",13.2},
            {"guindy","tambaram",19.5},{"tnagar","adyar",8.2},{"anna","egmore",9.4}
        };
        for (const auto& [from,to,km] : edges) {
            db->execute("INSERT INTO road_edges(from_node,to_node,distance_km) VALUES(?,?,?)",{from,to,std::to_string(km)});
            db->execute("INSERT INTO road_edges(from_node,to_node,distance_km) VALUES(?,?,?)",{to,from,std::to_string(km)});
        }
    }
    if (db->first("SELECT id FROM areas LIMIT 1").empty()) {
        const std::vector<std::tuple<std::string,std::string,std::string,double,double,int,double,std::string,std::string>> areas = {
            {"Sundaram Apartments","Apartment","Anna Nagar",13.085,80.210,420,0.42,"044-25011001","anna"},
            {"Green Park Residency","Apartment","Ambattur",13.114,80.155,280,0.63,"044-25011002","ambattur"},
            {"St. Mary's Medical Centre","Hospital","Kilpauk",13.083,80.238,190,0.88,"044-25011003","kilpauk"},
            {"Egmore Community Homes","Individual House","Egmore",13.073,80.261,85,0.71,"044-25011004","egmore"},
            {"Perambur Lakeview","Apartment","Perambur",13.116,80.234,360,0.56,"044-25011005","perambur"},
            {"Kaveri Children's Hospital","Hospital","T. Nagar",13.042,80.234,145,0.94,"044-25011006","tnagar"},
            {"Guindy Worker Colony","Individual House","Guindy",13.007,80.221,120,0.77,"044-25011007","guindy"},
            {"Adyar Cooperative Homes","Apartment","Adyar",13.001,80.257,310,0.39,"044-25011008","adyar"},
            {"Velachery Relief Centre","Hospital","Velachery",12.975,80.221,160,0.91,"044-25011009","velachery"},
            {"Tambaram South Homes","Individual House","Tambaram",12.925,80.100,95,0.69,"044-25011010","tambaram"}
        };
        for (const auto& [name,type,location,lat,lng,population,vuln,contact,node] : areas)
            db->execute("INSERT INTO areas(name,type,location,lat,lng,population,vulnerability,contact,road_node,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                {name,type,location,std::to_string(lat),std::to_string(lng),std::to_string(population),std::to_string(vuln),contact,node,timestamp()});
        const std::vector<std::tuple<int,int,std::string,double,std::string>> requests = {
            {1,9000,"Critical",0.94, "Emergency ward and patient care"},{2,6200,"High",0.63,"Storage is below one day"},
            {3,11000,"Critical",0.96,"Clinical water reserve"},{4,4200,"Medium",0.71,"Community supply request"},
            {5,7500,"High",0.56,"Apartment block reserve"},{6,8000,"Critical",0.91,"Patient services"},
            {7,5300,"High",0.77,"Worker housing supply"},{8,6800,"Normal",0.39,"Scheduled top-up"},
            {9,12000,"Critical",0.93,"Hospital reserve"},{10,4500,"Medium",0.69,"Household request"},
            {1,3800,"Medium",0.42,"Additional household demand"},{2,5100,"Normal",0.63,"Routine request"},
            {4,6400,"High",0.71,"Low stored supply"},{5,5800,"Medium",0.56,"Apartment block request"},
            {8,4300,"Normal",0.39,"Scheduled delivery"}
        };
        for (size_t i=0;i<requests.size();++i) {
            const auto& [area,litres,urgency,vulnerability,remarks]=requests[i];
            db->execute("INSERT INTO water_requests(area_id,requested_litres,remaining_litres,urgency,vulnerability,created_at,remarks,status) VALUES(?,?,?,?,?,datetime('now',?),?,'Pending')",
                {std::to_string(area),std::to_string(litres),std::to_string(litres),urgency,std::to_string(vulnerability),"-"+std::to_string((i+1)*3)+" hours",remarks});
        }
        const std::vector<std::tuple<std::string,std::string,int,std::string,std::string,std::string>> tankers = {
            {"TN 01 AB 2201","Large",12000,"R. Kumar","9000000001","anna"},{"TN 01 AB 2202","Large",12000,"S. Devi","9000000002","anna"},
            {"TN 01 AB 2203","Small",6000,"M. Arul","9000000003","anna"},{"TN 01 AB 2204","Large",12000,"P. Selvam","9000000004","anna"},
            {"TN 01 AB 2205","Small",6000,"K. Meena","9000000005","anna"},{"TN 01 AB 2206","Large",12000,"V. Ravi","9000000006","anna"},
            {"TN 01 AB 2207","Small",6000,"A. Balan","9000000007","anna"},{"TN 01 AB 2208","Large",12000,"J. Rani","9000000008","anna"}
        };
        for (const auto& [vehicle,size,capacity,driver,contact,node] : tankers)
            db->execute("INSERT INTO tankers(vehicle,size,capacity,current_water,driver,contact,status,road_node) VALUES(?,?,?,?,?,?,'Available',?)",
                {vehicle,size,std::to_string(capacity),std::to_string(capacity),driver,contact,node});
        activity("system","Demonstration dataset initialized");
    }
    db->execute("INSERT OR IGNORE INTO settings(key,value) VALUES('simulation_speed','0.18'),('depot_node','anna'),('weight_waiting','0.25'),('weight_demand','0.30'),('weight_vulnerability','0.25'),('weight_urgency','0.20')");
}

bool authorize(const httplib::Request& request, httplib::Response& response, const std::string& requiredRole = "") {
    const std::string header = request.get_header_value("Authorization");
    const std::string token = header.rfind("Bearer ",0)==0 ? header.substr(7) : "";
    if (token.empty()) { sendJson(response,401,{{"error","Authentication required"}}); return false; }
    auto user = db->first("SELECT users.id,users.username,users.role FROM sessions JOIN users ON users.id=sessions.user_id WHERE sessions.token=?",{token});
    if (user.empty()) { sendJson(response,401,{{"error","Session expired or invalid"}}); return false; }
    if (requiredRole == "admin" && value(user,"role") != "admin") { sendJson(response,403,{{"error","Administrator access required"}}); return false; }
    return true;
}

json publicAreas() { return db->rows("SELECT * FROM areas ORDER BY name"); }
json publicRequests() { return db->rows("SELECT r.*,a.name AS area_name,a.type AS area_type,a.location,a.road_node FROM water_requests r JOIN areas a ON a.id=r.area_id ORDER BY r.created_at"); }
json publicTankers() { return db->rows("SELECT t.*,a.name AS assigned_area FROM tankers t LEFT JOIN areas a ON a.id=t.assigned_area_id ORDER BY t.id"); }

void advanceSimulation() {
    while (trackingOn) {
        std::this_thread::sleep_for(seconds(1));
        if (!trackingOn) break;
        try {
            auto active = db->rows("SELECT d.id,d.request_id,d.tanker_id,d.amount_litres,d.distance_km,d.route_json,s.progress FROM deliveries d JOIN simulation_states s ON s.delivery_id=d.id WHERE s.status='In Transit'");
            for (const auto& item : active) {
                const int id=item["id"].get<int>();
                const double distance=item["distance_km"].get<double>();
                const double speed=std::stod(value(db->first("SELECT value FROM settings WHERE key='simulation_speed'"),"value","0.18"));
                const double progress=std::min(1.0,item["progress"].get<double>()+(distance > 0 ? speed/distance : 1.0));
                db->execute("UPDATE simulation_states SET progress=?,updated_at=? WHERE delivery_id=?",{std::to_string(progress),timestamp(),std::to_string(id)});
                if (progress >= 1.0) {
                    db->execute("UPDATE deliveries SET status='Delivered' WHERE id=?",{std::to_string(id)});
                    db->execute("UPDATE water_requests SET delivered_litres=delivered_litres+(SELECT amount_litres FROM deliveries WHERE id=?),remaining_litres=MAX(0,remaining_litres-(SELECT amount_litres FROM deliveries WHERE id=?)),status=CASE WHEN remaining_litres-(SELECT amount_litres FROM deliveries WHERE id=?)<=0 THEN 'Delivered' ELSE 'Partially Delivered' END WHERE id=?",{std::to_string(id),std::to_string(id),std::to_string(id),value(item,"request_id")});
                    db->execute("UPDATE tankers SET current_water=MAX(0,current_water-?),status='Available',assigned_area_id=NULL WHERE id=?",{value(item,"amount_litres"),value(item,"tanker_id")});
                    db->execute("UPDATE simulation_states SET status='Delivered',progress=1,updated_at=? WHERE delivery_id=?",{timestamp(),std::to_string(id)});
                    activity("delivery","Delivery #"+std::to_string(id)+" completed");
                }
            }
        } catch (const std::exception& error) { std::cerr << "Tracking update: " << error.what() << '\n'; }
    }
}

} // namespace

int main() {
    try {
        const char* configured = std::getenv("FAIRFLOW_DB");
        const std::string databasePath = configured ? configured : "backend/database/fairflow.sqlite";
        db = std::make_unique<Database>(databasePath);
        initializeDatabase();
        tracker = std::thread(advanceSimulation);
        httplib::Server server;
        server.set_payload_max_length(1024 * 1024);
        server.set_pre_routing_handler([](const httplib::Request&, httplib::Response& response) {
            response.set_header("Access-Control-Allow-Origin","http://127.0.0.1:5173");
            response.set_header("Access-Control-Allow-Headers","Content-Type, Authorization");
            response.set_header("Access-Control-Allow-Methods","GET, POST, PUT, DELETE, OPTIONS");
            if (response.status == 0) response.status = 200;
            return httplib::Server::HandlerResponse::Unhandled;
        });
        server.Options(R"(/api/.*)",[](const httplib::Request&,httplib::Response& response){ response.status=204; });
        auto body = [](const httplib::Request& request) { return json::parse(request.body.empty()?"{}":request.body); };
        auto protect = [](const httplib::Request& request, httplib::Response& response, const std::string& role="") { return authorize(request,response,role); };

        server.Get("/api/health",[](const httplib::Request&,httplib::Response& response){ sendJson(response,200,{{"status","ok"},{"service","fairflow-cpp"}}); });
        server.Post("/api/auth/login",[&](const httplib::Request& request,httplib::Response& response){
            auto data=body(request); const auto email=value(data,"email"); const auto password=value(data,"password");
            const auto selectedRole=value(data,"role");
            if(selectedRole!="admin"&&selectedRole!="operator"){sendJson(response,400,{{"error","Select a valid account type"}});return;}
            auto user=db->first("SELECT * FROM users WHERE email=? AND role=?",{email,selectedRole});
            if(user.empty()||!verifyPassword(password,value(user,"password_hash"))){sendJson(response,401,{{"error","Email or password is incorrect. Create an account if you are new."}});return;}
            if(selectedRole=="admin"&&value(data,"pin")!="060506"){sendJson(response,401,{{"error","Invalid administrator security PIN"}});return;}
            const auto token=randomHex(32); db->execute("INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)",{token,value(user,"id"),timestamp()});
            activity("auth",value(user,"username")+" signed in"); sendJson(response,200,{{"token",token},{"user",{{"id",user["id"]},{"username",user["username"]},{"email",user["email"]},{"role",user["role"]}}}});
        });
        server.Post("/api/auth/register",[&](const httplib::Request& request,httplib::Response& response){
            auto data=body(request); const auto email=value(data,"email"); const auto password=value(data,"password"); const auto role=value(data,"role");
            if(role!="admin"&&role!="operator"){sendJson(response,400,{{"error","Select Admin or Operator account type"}});return;}
            if(email.size()<5||email.find('@')==std::string::npos||email.find('.')==std::string::npos){sendJson(response,400,{{"error","Enter a valid email address"}});return;}
            if(password.size()<8){sendJson(response,400,{{"error","Password must be at least 8 characters"}});return;}
            if(role=="admin"&&value(data,"pin")!="060506"){sendJson(response,401,{{"error","Invalid administrator security PIN"}});return;}
            if(!db->first("SELECT id FROM users WHERE email=?",{email}).empty()){sendJson(response,409,{{"error","An account with this email already exists. Sign in instead."}});return;}
            db->execute("INSERT INTO users(username,email,password_hash,role) VALUES(?,?,?,?)",{email,email,newPasswordHash(password),role});
            auto user=db->first("SELECT id,username,email,role FROM users WHERE id=last_insert_rowid()");
            const auto token=randomHex(32); db->execute("INSERT INTO sessions(token,user_id,created_at) VALUES(?,?,?)",{token,value(user,"id"),timestamp()});
            activity("auth",email+" created a "+role+" account");
            sendJson(response,201,{{"token",token},{"user",user}});
        });
        server.Get("/api/auth/me",[&](const httplib::Request& request,httplib::Response& response){ if(!protect(request,response))return; const auto token=request.get_header_value("Authorization").substr(7); sendJson(response,200,db->first("SELECT users.id,username,email,role FROM sessions JOIN users ON users.id=sessions.user_id WHERE token=?",{token})); });
        server.Post("/api/auth/logout",[&](const httplib::Request& request,httplib::Response& response){ const auto token=request.get_header_value("Authorization").substr(7); db->execute("DELETE FROM sessions WHERE token=?",{token}); sendJson(response,200,{{"ok",true}}); });

        server.Get("/api/areas",[&](const httplib::Request& request,httplib::Response& response){if(protect(request,response))sendJson(response,200,publicAreas());});
        server.Post("/api/areas",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;auto d=body(request);for(auto key:{"name","type","location","lat","lng","population","vulnerability","contact","road_node"})if(!d.contains(key)){sendJson(response,400,{{"error",std::string("Missing field: ")+key}});return;}db->execute("INSERT INTO areas(name,type,location,lat,lng,population,vulnerability,contact,road_node,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",{value(d,"name"),value(d,"type"),value(d,"location"),value(d,"lat"),value(d,"lng"),value(d,"population"),value(d,"vulnerability"),value(d,"contact"),value(d,"road_node"),timestamp()});activity("area","Area registered: "+value(d,"name"));sendJson(response,201,db->first("SELECT * FROM areas WHERE id=last_insert_rowid()"));});
        server.Put(R"(/api/areas/(\d+))",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;auto d=body(request);db->execute("UPDATE areas SET name=?,type=?,location=?,lat=?,lng=?,population=?,vulnerability=?,contact=?,road_node=? WHERE id=?",{value(d,"name"),value(d,"type"),value(d,"location"),value(d,"lat"),value(d,"lng"),value(d,"population"),value(d,"vulnerability"),value(d,"contact"),value(d,"road_node"),request.matches[1]});sendJson(response,200,db->first("SELECT * FROM areas WHERE id=?",{request.matches[1]}));});
        server.Delete(R"(/api/areas/(\d+))",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;db->execute("DELETE FROM areas WHERE id=?",{request.matches[1]});sendJson(response,200,{{"ok",true}});});

        server.Get("/api/requests",[&](const httplib::Request& request,httplib::Response& response){if(protect(request,response))sendJson(response,200,publicRequests());});
        server.Post("/api/requests",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;auto d=body(request);const int amount=std::stoi(value(d,"requested_litres","0"));if(amount<=0||value(d,"area_id").empty()||db->first("SELECT id FROM areas WHERE id=?",{value(d,"area_id")}).empty()){sendJson(response,400,{{"error","Choose an existing area and enter a quantity greater than zero"}});return;}db->execute("INSERT INTO water_requests(area_id,requested_litres,remaining_litres,urgency,vulnerability,created_at,remarks,status) VALUES(?,?,?,?,?,?,?,'Pending')",{value(d,"area_id"),std::to_string(amount),std::to_string(amount),value(d,"urgency","Normal"),value(d,"vulnerability","0"),timestamp(),value(d,"remarks")});activity("request",value(d,"urgency")=="Critical"?"Critical request registered":"New water request registered");sendJson(response,201,db->first("SELECT * FROM water_requests WHERE id=last_insert_rowid()"));});
        server.Put(R"(/api/requests/(\d+))",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;auto d=body(request);db->execute("UPDATE water_requests SET urgency=?,remarks=?,vulnerability=? WHERE id=?",{value(d,"urgency","Normal"),value(d,"remarks"),value(d,"vulnerability","0"),request.matches[1]});sendJson(response,200,db->first("SELECT * FROM water_requests WHERE id=?",{request.matches[1]}));});
        server.Delete(R"(/api/requests/(\d+))",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;db->execute("DELETE FROM water_requests WHERE id=?",{request.matches[1]});sendJson(response,200,{{"ok",true}});});

        server.Get("/api/tankers",[&](const httplib::Request& request,httplib::Response& response){if(protect(request,response))sendJson(response,200,publicTankers());});
        server.Post("/api/tankers",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;auto d=body(request);const auto size=value(d,"size","Small");const int capacity=size=="Large"?12000:6000;db->execute("INSERT INTO tankers(vehicle,size,capacity,current_water,driver,contact,status,road_node) VALUES(?,?,?,?,?,?,?,?)",{value(d,"vehicle"),size,std::to_string(capacity),value(d,"current_water",std::to_string(capacity)),value(d,"driver"),value(d,"contact"),"Available",value(d,"road_node","anna")});sendJson(response,201,db->first("SELECT * FROM tankers WHERE id=last_insert_rowid()"));});
        server.Put(R"(/api/tankers/(\d+))",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;auto d=body(request);const auto size=value(d,"size","Small");const int capacity=size=="Large"?12000:6000;db->execute("UPDATE tankers SET vehicle=?,size=?,capacity=?,current_water=MIN(?,?),driver=?,contact=?,road_node=? WHERE id=?",{value(d,"vehicle"),size,std::to_string(capacity),value(d,"current_water",std::to_string(capacity)),std::to_string(capacity),value(d,"driver"),value(d,"contact"),value(d,"road_node","anna"),request.matches[1]});sendJson(response,200,db->first("SELECT * FROM tankers WHERE id=?",{request.matches[1]}));});
        server.Delete(R"(/api/tankers/(\d+))",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;db->execute("DELETE FROM tankers WHERE id=?",{request.matches[1]});sendJson(response,200,{{"ok",true}});});

        server.Post("/api/allocation/run",[&](const httplib::Request& request,httplib::Response& response){
            if(!protect(request,response,"admin"))return;auto d=body(request);const auto strategy=value(d,"strategy","FAIRNESS-FIRST");
            if(strategy!="FCFS"&&strategy!="NEAREST-FIRST"&&strategy!="FAIRNESS-FIRST"){sendJson(response,400,{{"error","Unknown allocation strategy"}});return;}
            const double wWait=std::stod(value(d,"weight_waiting","0.25")),wDemand=std::stod(value(d,"weight_demand","0.30")),wVuln=std::stod(value(d,"weight_vulnerability","0.25")),wUrgency=std::stod(value(d,"weight_urgency","0.20"));
            if(std::abs(wWait+wDemand+wVuln+wUrgency-1.0)>0.001||std::min({wWait,wDemand,wVuln,wUrgency})<0){sendJson(response,400,{{"error","Fairness weights must be non-negative and add up to 1"}});return;}
            auto requests=db->rows("SELECT r.*,a.name AS area_name,a.road_node FROM water_requests r JOIN areas a ON a.id=r.area_id WHERE r.status IN ('Pending','Partially Delivered') AND r.remaining_litres>0 ORDER BY r.created_at");
            auto tankers=db->rows("SELECT * FROM tankers WHERE status='Available' AND current_water>0 ORDER BY id");
            const auto depot=value(db->first("SELECT value FROM settings WHERE key='depot_node'"),"value","anna");
            std::unordered_map<int,double> scores;std::unordered_map<int,double> distances;double maxWait=1,maxDemand=1;
            const auto now=system_clock::now();for(const auto&r:requests){const double age=std::max(0.0,duration<double>(now-system_clock::from_time_t(parseUtc(value(r,"created_at")))).count()/3600.0);maxWait=std::max(maxWait,age);maxDemand=std::max(maxDemand,static_cast<double>(r["remaining_litres"].get<int>()));try{distances[r["id"].get<int>()]=shortestPath(depot,value(r,"road_node")).distance;}catch(...){distances[r["id"].get<int>()]=9999;}}
            std::unordered_map<int,json> scoreParts;
            auto priority=[&](const json&r){const auto id=r["id"].get<int>();const auto urgency=value(r,"urgency");const double urgencyValue=urgency=="Critical"?1.0:urgency=="High"?0.75:urgency=="Medium"?0.5:0.25;const double ageHours=std::max(0.0,duration<double>(now-system_clock::from_time_t(parseUtc(value(r,"created_at")))).count()/3600.0);const double waiting=wWait*std::min(1.0,ageHours/maxWait);const double unmet=wDemand*std::min(1.0,r["remaining_litres"].get<double>()/maxDemand);const double vulnerability=wVuln*std::clamp(r["vulnerability"].get<double>(),0.0,1.0);const double urgencyContribution=wUrgency*urgencyValue;const double score=waiting+unmet+vulnerability+urgencyContribution;scores[id]=score;scoreParts[id]={{"waiting_contribution",waiting},{"unmet_contribution",unmet},{"vulnerability_contribution",vulnerability},{"urgency_contribution",urgencyContribution}};return score;};
            if(strategy=="FAIRNESS-FIRST") { using Scored=std::pair<double,size_t>;std::priority_queue<Scored> q;for(size_t i=0;i<requests.size();++i)q.push({priority(requests[i]),i});std::vector<json> sorted;while(!q.empty()){sorted.push_back(requests[q.top().second]);q.pop();}requests=std::move(sorted); }
            else if(strategy=="NEAREST-FIRST")std::stable_sort(requests.begin(),requests.end(),[&](const json&a,const json&b){return distances[a["id"].get<int>()]<distances[b["id"].get<int>()];});
            json assignments=json::array();int rank=0;
            for(const auto&r:requests){++rank;const int requestId=r["id"].get<int>();auto chosen=tankers.end();for(auto it=tankers.begin();it!=tankers.end();++it){if(it->at("current_water").get<int>()<=0||value(*it,"status")!="Available")continue;if(strategy=="NEAREST-FIRST"){try{const auto origin=value(*it,"road_node");const double distance=shortestPath(origin,value(r,"road_node")).distance;if(chosen==tankers.end()||distance<shortestPath(value(*chosen,"road_node"),value(r,"road_node")).distance)chosen=it;}catch(...){}}else{chosen=it;break;}}
                if(chosen==tankers.end())continue;const int amount=std::min(r["remaining_litres"].get<int>(),chosen->at("current_water").get<int>());const auto route=shortestPath(value(*chosen,"road_node"),value(r,"road_node"));const double score=strategy=="FAIRNESS-FIRST"?scores[requestId]:0.0;
                db->execute("INSERT INTO allocations(request_id,tanker_id,amount_litres,strategy,priority_score,created_at) VALUES(?,?,?,?,?,?)",{std::to_string(requestId),value(*chosen,"id"),std::to_string(amount),strategy,std::to_string(score),timestamp()});const auto allocationId=sqlite3_last_insert_rowid(db->handle);
                json path=route.nodes;db->execute("INSERT INTO deliveries(allocation_id,request_id,tanker_id,amount_litres,distance_km,route_json,status,created_at) VALUES(?,?,?,?,?,?,'Pending',?)",{std::to_string(allocationId),std::to_string(requestId),value(*chosen,"id"),std::to_string(amount),std::to_string(route.distance),path.dump(),timestamp()});const auto deliveryId=sqlite3_last_insert_rowid(db->handle);
                db->execute("INSERT INTO simulation_states(delivery_id,progress,status,updated_at) VALUES(?,0,'Pending',?)",{std::to_string(deliveryId),timestamp()});db->execute("UPDATE water_requests SET status='Allocated' WHERE id=?",{std::to_string(requestId)});db->execute("UPDATE tankers SET status='Assigned',assigned_area_id=(SELECT area_id FROM water_requests WHERE id=?) WHERE id=?",{std::to_string(requestId),value(*chosen,"id")});chosen->at("current_water")=chosen->at("current_water").get<int>()-amount;chosen->at("status")="Assigned";
                assignments.push_back({{"rank",rank},{"request_id",requestId},{"area_name",r["area_name"]},{"tanker_id",chosen->at("id")},{"amount_litres",amount},{"priority_score",score},{"distance_km",route.distance},{"delivery_id",deliveryId},{"route",path}});
            }
            for(const auto&r:requests)if(scores.count(r["id"].get<int>()))db->execute("UPDATE water_requests SET status=CASE WHEN status='Pending' AND ?=0 THEN 'Unserved' ELSE status END WHERE id=?",{assignments.empty()?"0":"1",value(r,"id")});
            activity("allocation",strategy+" allocation run created "+std::to_string(assignments.size())+" assignment(s)");sendJson(response,200,{{"strategy",strategy},{"assignments",assignments},{"rankings",[&](){json out=json::array();int i=0;for(const auto&r:requests){++i;const int id=r["id"].get<int>();json item={{"rank",i},{"request_id",id},{"area_name",r["area_name"]},{"score",scores.count(id)?scores[id]:0.0}};if(scoreParts.count(id))for(const auto&[key,part]:scoreParts[id].items())item[key]=part;out.push_back(item);}return out;}()}});
        });
        server.Get("/api/allocation/results",[&](const httplib::Request& request,httplib::Response& response){if(protect(request,response))sendJson(response,200,db->rows("SELECT a.*,r.area_id,ar.name AS area_name,t.vehicle,d.id AS delivery_id,d.distance_km,d.status AS delivery_status FROM allocations a JOIN water_requests r ON r.id=a.request_id JOIN areas ar ON ar.id=r.area_id JOIN tankers t ON t.id=a.tanker_id LEFT JOIN deliveries d ON d.allocation_id=a.id ORDER BY a.created_at DESC"));});
        server.Get("/api/allocation/compare",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;json results=json::array();for(const auto&strategy:{"FCFS","NEAREST-FIRST","FAIRNESS-FIRST"}){auto available=db->rows("SELECT current_water FROM tankers WHERE status='Available'");auto pending=db->rows("SELECT r.id,r.remaining_litres,r.vulnerability,r.urgency,r.created_at,a.road_node FROM water_requests r JOIN areas a ON a.id=r.area_id WHERE r.status IN ('Pending','Partially Delivered')");int delivered=0,served=0;double distance=0,wait=0;std::vector<double> areaWater;for(const auto&r:pending)areaWater.push_back(0);if(std::string(strategy)=="NEAREST-FIRST"){std::stable_sort(pending.begin(),pending.end(),[&](const json&a,const json&b){return shortestPath("anna",value(a,"road_node")).distance<shortestPath("anna",value(b,"road_node")).distance;});}for(size_t i=0;i<pending.size()&&i<available.size();++i){int amount=std::min(pending[i]["remaining_litres"].get<int>(),available[i]["current_water"].get<int>());delivered+=amount;if(amount>=pending[i]["remaining_litres"].get<int>())++served;distance+=shortestPath("anna",value(pending[i],"road_node")).distance;areaWater[i]=amount;}double sum=0,square=0;for(double amount:areaWater){sum+=amount;square+=amount*amount;}results.push_back({{"strategy",strategy},{"water_delivered",delivered},{"completed_requests",served},{"average_wait_hours",wait},{"travel_distance_km",distance},{"unmet_demand",std::max(0,([&](){int total=0;for(const auto&r:pending)total+=r["remaining_litres"].get<int>();return total;})()-delivered)},{"fairness_index",square>0?sum*sum/(areaWater.size()*square):0}});}sendJson(response,200,results);});

        server.Get("/api/routes/network",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;sendJson(response,200,{{"nodes",db->rows("SELECT * FROM road_nodes")},{"edges",db->rows("SELECT * FROM road_edges WHERE from_node<to_node")},{"depot","anna"}});});
        server.Post("/api/routes/shortest-path",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;auto d=body(request);try{const auto route=shortestPath(value(d,"from","anna"),value(d,"to"));sendJson(response,200,{{"nodes",route.nodes},{"distance_km",route.distance},{"estimated_minutes",route.distance/30.0*60.0}});}catch(const std::exception&e){sendJson(response,400,{{"error",e.what()}});}});
        server.Get("/api/tracking/active",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;sendJson(response,200,db->rows("SELECT d.*,s.progress,s.status AS simulation_status,t.vehicle,t.size,t.current_water,a.name AS area_name,a.road_node FROM deliveries d JOIN simulation_states s ON s.delivery_id=d.id JOIN tankers t ON t.id=d.tanker_id JOIN water_requests r ON r.id=d.request_id JOIN areas a ON a.id=r.area_id WHERE s.status IN ('Pending','In Transit','Paused') ORDER BY d.id DESC"));});
        auto trackingAction=[&](const httplib::Request& request,httplib::Response& response,const std::string& action){if(!protect(request,response))return;const auto d=body(request);const auto id=value(d,"delivery_id");if(action=="start"||action=="resume"){db->execute("UPDATE simulation_states SET status='In Transit',updated_at=? WHERE delivery_id=?",{timestamp(),id});db->execute("UPDATE deliveries SET status='In Transit' WHERE id=?",{id});db->execute("UPDATE tankers SET status='In Transit' WHERE id=(SELECT tanker_id FROM deliveries WHERE id=?)",{id});}else if(action=="pause"){db->execute("UPDATE simulation_states SET status='Paused',updated_at=? WHERE delivery_id=?",{timestamp(),id});db->execute("UPDATE deliveries SET status='Paused' WHERE id=?",{id});}else if(action=="complete"){db->execute("UPDATE simulation_states SET status='In Transit',progress=0.99,updated_at=? WHERE delivery_id=?",{timestamp(),id});}sendJson(response,200,{{"ok",true},{"delivery_id",id}});};
        server.Post("/api/tracking/start",[&](const auto&r,auto&s){trackingAction(r,s,"start");});server.Post("/api/tracking/pause",[&](const auto&r,auto&s){trackingAction(r,s,"pause");});server.Post("/api/tracking/resume",[&](const auto&r,auto&s){trackingAction(r,s,"resume");});server.Post("/api/tracking/complete",[&](const auto&r,auto&s){trackingAction(r,s,"complete");});

        server.Get("/api/dashboard/stats",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;auto scalar=[&](const std::string&sql){auto r=db->first(sql);return r.empty()?0.0:(r.begin().value().is_number()?r.begin().value().get<double>():std::stod(r.begin().value().get<std::string>()));};sendJson(response,200,{{"areas",scalar("SELECT COUNT(*) AS n FROM areas")},{"requests",scalar("SELECT COUNT(*) AS n FROM water_requests")},{"pending",scalar("SELECT COUNT(*) AS n FROM water_requests WHERE status IN ('Pending','Allocated','In Transit')")},{"completed",scalar("SELECT COUNT(*) AS n FROM water_requests WHERE status='Delivered'")},{"available_tankers",scalar("SELECT COUNT(*) AS n FROM tankers WHERE status='Available'")},{"active_tankers",scalar("SELECT COUNT(*) AS n FROM tankers WHERE status IN ('Assigned','In Transit')")},{"water_demanded",scalar("SELECT COALESCE(SUM(requested_litres),0) AS n FROM water_requests")},{"water_delivered",scalar("SELECT COALESCE(SUM(delivered_litres),0) AS n FROM water_requests")},{"unmet_demand",scalar("SELECT COALESCE(SUM(remaining_litres),0) AS n FROM water_requests")},{"recent_activity",db->rows("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 8")}});});
        server.Get("/api/dashboard/analytics",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;sendJson(response,200,{{"demand_by_area",db->rows("SELECT a.name,a.type,SUM(r.requested_litres) AS demand,SUM(r.delivered_litres) AS delivered FROM areas a LEFT JOIN water_requests r ON r.area_id=a.id GROUP BY a.id ORDER BY demand DESC")},{"statuses",db->rows("SELECT status,COUNT(*) AS count FROM water_requests GROUP BY status")},{"distribution",db->rows("SELECT type,SUM(delivered_litres) AS delivered FROM areas a LEFT JOIN water_requests r ON r.area_id=a.id GROUP BY type")},{"utilization",db->rows("SELECT vehicle,size,capacity,current_water,status FROM tankers")}});});
        server.Get("/api/reports/summary",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;sendJson(response,200,{{"requests",publicRequests()},{"tankers",publicTankers()},{"allocations",db->rows("SELECT * FROM allocations")},{"deliveries",db->rows("SELECT * FROM deliveries")},{"stats",db->first("SELECT COUNT(*) AS total_requests,COALESCE(SUM(requested_litres),0) AS total_demand,COALESCE(SUM(delivered_litres),0) AS total_delivered,COALESCE(SUM(remaining_litres),0) AS unmet_demand,AVG(julianday('now')-julianday(created_at))*24 AS average_wait_hours FROM water_requests")}});});
        server.Get("/api/reports/export",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response))return;auto rows=db->rows("SELECT r.id,a.name AS area,r.requested_litres,r.delivered_litres,r.remaining_litres,r.urgency,r.status,r.created_at FROM water_requests r JOIN areas a ON a.id=r.area_id ORDER BY r.id");std::ostringstream csv;csv<<"request_id,area,requested_litres,delivered_litres,unmet_litres,urgency,status,created_at\r\n";for(const auto&r:rows)csv<<r["id"]<<",\""<<r["area"]<<"\","<<r["requested_litres"]<<","<<r["delivered_litres"]<<","<<r["remaining_litres"]<<",\""<<r["urgency"]<<"\",\""<<r["status"]<<"\",\""<<r["created_at"]<<"\"\r\n";response.set_content(csv.str(),"text/csv; charset=utf-8");response.set_header("Content-Disposition","attachment; filename=fairflow-report.csv");});
        server.Get("/api/activity",[&](const httplib::Request& request,httplib::Response& response){if(protect(request,response))sendJson(response,200,db->rows("SELECT * FROM activity_logs ORDER BY id DESC LIMIT 50"));});
        server.Get("/api/settings",[&](const httplib::Request& request,httplib::Response& response){if(protect(request,response))sendJson(response,200,db->rows("SELECT key,value FROM settings"));});
        server.Put("/api/settings",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;auto d=body(request);for(const auto&[key,val]:d.items())db->execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",{key,val.is_string()?val.get<std::string>():val.dump()});sendJson(response,200,{{"ok",true}});});
        server.Post("/api/demo/reset",[&](const httplib::Request& request,httplib::Response& response){if(!protect(request,response,"admin"))return;db->execute("DELETE FROM simulation_states;DELETE FROM deliveries;DELETE FROM allocations;DELETE FROM water_requests;DELETE FROM tankers;DELETE FROM areas;DELETE FROM activity_logs;DELETE FROM road_edges;DELETE FROM road_nodes;DELETE FROM sqlite_sequence WHERE name IN ('areas','water_requests','tankers','allocations','deliveries','road_edges','activity_logs');");initializeDatabase();sendJson(response,200,{{"ok",true},{"message","Operational demonstration data restored; accounts preserved"}});});

        server.set_error_handler([](const httplib::Request&,httplib::Response& response){if(response.body.empty())sendJson(response,404,{{"error","API endpoint not found"}});});
        server.set_exception_handler([](const httplib::Request&,httplib::Response& response,std::exception_ptr error){try{if(error)std::rethrow_exception(error);}catch(const std::exception&e){sendJson(response,500,{{"error",e.what()}});}catch(...){sendJson(response,500,{{"error","Unexpected server error"}});}});
        const int port=std::getenv("FAIRFLOW_PORT")?std::stoi(std::getenv("FAIRFLOW_PORT")):8080;
        std::cout<<"FairFlow C++ API listening at http://127.0.0.1:"<<port<<"\nDatabase: "<<databasePath<<"\n";
        if(!server.listen("127.0.0.1",port))throw std::runtime_error("Unable to bind API port");
        trackingOn=false;if(tracker.joinable())tracker.join();
        return 0;
    } catch(const std::exception& error) { std::cerr<<"FairFlow startup error: "<<error.what()<<'\n';return 1; }
}
