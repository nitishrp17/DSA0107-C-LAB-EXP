import { useEffect, useState } from 'react';
import {
  Activity, ArrowDownToLine, ArrowRight, Bell, Building2, Check, ChevronDown, CircleHelp,
  Clock3, Droplets, Gauge, Hospital, House, LayoutDashboard, LogOut, Map, Menu, Plus,
  Search, Settings, ShieldCheck, Truck, Waves, X, Zap,
} from 'lucide-react';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Legend, Pie, PieChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts';
import { CircleMarker, MapContainer, Polyline, Popup, TileLayer, useMap } from 'react-leaflet';
import { api, getToken, setToken } from './api.js';

const NAV = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'requests', label: 'Water requests', icon: Droplets },
  { id: 'areas', label: 'Service areas', icon: Building2 },
  { id: 'tankers', label: 'Tanker fleet', icon: Truck },
  { id: 'allocation', label: 'Allocation engine', icon: Zap },
  { id: 'routes', label: 'Routes & tracking', icon: Map },
  { id: 'reports', label: 'Performance', icon: Gauge },
];
const NODE_COORDS = {
  anna: [13.085, 80.210], ambattur: [13.1143, 80.1548], kilpauk: [13.0827, 80.238],
  egmore: [13.0732, 80.2609], perambur: [13.1161, 80.2336], tnagar: [13.0418, 80.2341],
  guindy: [13.0067, 80.2206], adyar: [13.0012, 80.2565], velachery: [12.975, 80.2212], tambaram: [12.9249, 80.1],
};
const NODE_LABELS = { anna: 'Anna Nagar', ambattur: 'Ambattur', kilpauk: 'Kilpauk', egmore: 'Egmore', perambur: 'Perambur', tnagar: 'T. Nagar', guindy: 'Guindy', adyar: 'Adyar', velachery: 'Velachery', tambaram: 'Tambaram' };
const TYPE_COLORS = { Hospital: '#d66c4b', Apartment: '#338777', 'Individual House': '#c49a46' };
const fmt = (n) => new Intl.NumberFormat('en-IN').format(Number(n || 0));
const shortDate = (date) => date ? new Date(date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }) : '—';

function Brand({ compact = false }) {
  return <div className={`brand ${compact ? 'brand-compact' : ''}`}><span className="brand-mark"><Droplets size={18} strokeWidth={2.2} /><i /></span><span className="brand-name">fairflow<span>WATER OPERATIONS</span></span></div>;
}

function Login({ onLogin, onRegister, error }) {
  const [role, setRole] = useState('admin');
  const [mode, setMode] = useState('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [pin, setPin] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    if (mode === 'register' && password !== confirmPassword) return;
    setBusy(true);
    try {
      if (mode === 'register') await onRegister(email, password, role, role === 'admin' ? pin : '');
      else await onLogin(email, password, role, role === 'admin' ? pin : '');
    } finally {
      setBusy(false);
    }
  }

  function chooseRole(nextRole) {
    setRole(nextRole);
    setPin('');
  }

  function chooseMode(nextMode) {
    setMode(nextMode);
    setPassword('');
    setConfirmPassword('');
    setPin('');
  }

  return (
    <main className="login-page">
      <div className="login-aside">
        <Brand />
        <div className="login-headline">
          <span className="eyebrow">A fairer flow, by design</span>
          <h1>Every drop,<br /><em>accounted for.</em></h1>
          <p>One clear view of water demand, equitable allocation and every simulated delivery across the service network.</p>
          <div className="login-stat"><span className="stat-orbit"><Waves size={22} /></span><div><b>Fairness in every route</b><small>Priority-aware water distribution</small></div></div>
        </div>
        <div className="login-foot">ACADEMIC ENGINEERING PROJECT · SIMULATED CHENNAI NETWORK</div>
      </div>
      <section className="login-panel">
        <form className="login-form" onSubmit={submit}>
          <span className="eyebrow">OPERATIONS PORTAL</span>
          <h2>{mode === 'signin' ? 'Sign in to FairFlow' : 'Create your account'}</h2>
          <p className="muted">Select your role and {mode === 'signin' ? 'enter your account details.' : 'register with your email and password.'}</p>
          <div className="mode-switch" role="group" aria-label="Sign in or create account">
            <button type="button" className={mode === 'signin' ? 'selected' : ''} aria-pressed={mode === 'signin'} onClick={() => chooseMode('signin')}>Sign in</button>
            <button type="button" className={mode === 'register' ? 'selected' : ''} aria-pressed={mode === 'register'} onClick={() => chooseMode('register')}>Create account</button>
          </div>
          <div className="role-switch" role="group" aria-label="Choose login role">
            <button type="button" className={role === 'admin' ? 'selected' : ''} aria-pressed={role === 'admin'} onClick={() => chooseRole('admin')}><ShieldCheck size={15} />Admin</button>
            <button type="button" className={role === 'operator' ? 'selected' : ''} aria-pressed={role === 'operator'} onClick={() => chooseRole('operator')}><Truck size={15} />Operator</button>
          </div>
          <label>Email address<input type="email" autoComplete="email" placeholder="you@example.com" value={email} onChange={(event) => setEmail(event.target.value)} required /></label>
          <label>Password<input type="password" autoComplete={mode === 'signin' ? 'current-password' : 'new-password'} minLength={8} placeholder={mode === 'signin' ? 'Enter your password' : 'At least 8 characters'} value={password} onChange={(event) => setPassword(event.target.value)} required /></label>
          {mode === 'register' && <label>Confirm password<input type="password" autoComplete="new-password" minLength={8} placeholder="Re-enter your password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} required /></label>}
          {role === 'admin' && <label>Administrator security PIN<input type="password" inputMode="numeric" autoComplete="one-time-code" pattern="[0-9]{6}" maxLength={6} placeholder="Enter 6-digit PIN" value={pin} onChange={(event) => setPin(event.target.value.replace(/\D/g, '').slice(0, 6))} required aria-describedby="admin-pin-help" /><small id="admin-pin-help" className="field-hint">Required for Admin sign-in and account creation</small></label>}
          {mode === 'register' && password && confirmPassword && password !== confirmPassword && <div className="form-error">Passwords do not match.</div>}
          {error && <div className="form-error">{error}</div>}
          <button className="button button-primary login-submit" disabled={busy || (role === 'admin' && pin.length !== 6) || (mode === 'register' && password !== confirmPassword)}>{busy ? 'Please wait…' : mode === 'signin' ? 'Sign in' : 'Create account'}<ArrowRight size={16} /></button>
          <p className="login-policy">{role === 'admin' ? 'Admin access uses your account email, password and the shared security PIN.' : 'Operator access uses your registered email and password.'}</p>
        </form>
        <div className="login-bottom">Browser-local account · Saved on this device</div>
      </section>
    </main>
  );
}

function StatCard({ label, value, note, icon: Icon, tone = 'green', unit = '' }) {
  return <article className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={18} /></div><div className="stat-copy"><span>{label}</span><strong>{fmt(value)}{unit && <small>{unit}</small>}</strong><small>{note}</small></div></article>;
}

function SectionTitle({ title, note, action }) {
  return <div className="section-title"><div><h2>{title}</h2>{note && <p>{note}</p>}</div>{action}</div>;
}

function Status({ children }) {
  const key = String(children || 'Pending').toLowerCase().replaceAll(' ', '-');
  return <span className={`status status-${key}`}><i />{children}</span>;
}

function Empty({ message }) { return <div className="empty-state"><Droplets size={20} /><span>{message}</span></div>; }

function Overview({ stats, analytics, activities, onNavigate }) {
  const areas = analytics?.demand_by_area || [];
  const statuses = analytics?.statuses || [];
  const utilization = (analytics?.utilization || []).map((t) => ({ name: t.vehicle?.slice(-4), used: Math.max(0, t.capacity - t.current_water), remaining: t.current_water }));
  return <>
    <SectionTitle title="Operations overview" note={`Live service picture · ${new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}`} action={<button className="button button-outline" onClick={() => onNavigate('routes')}><Activity size={15} /> Live operations</button>} />
    <div className="stats-grid"><StatCard label="Service areas" value={stats?.areas} note="Registered locations" icon={Building2} /><StatCard label="Water requests" value={stats?.requests} note="All-time records" icon={Droplets} tone="blue" /><StatCard label="Pending requests" value={stats?.pending} note="Awaiting delivery" icon={Clock3} tone="amber" /><StatCard label="Deliveries complete" value={stats?.completed} note="Confirmed at destination" icon={Check} tone="teal" /><StatCard label="Tankers available" value={stats?.available_tankers} note={`${stats?.active_tankers || 0} currently assigned`} icon={Truck} tone="blue" /><StatCard label="Water demanded" value={Number(stats?.water_demanded || 0) / 1000} unit="kL" note={`${fmt(stats?.water_delivered)} L delivered`} icon={Waves} tone="teal" /></div>
    <div className="dashboard-grid"><section className="panel chart-panel"><SectionTitle title="Demand by service area" note="Requested and delivered water · litres" /><div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={areas} margin={{ top: 8, right: 12, bottom: 4, left: 0 }}><CartesianGrid stroke="#e9eeea" vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 10, fill: '#78827c' }} tickLine={false} axisLine={false} interval={0} angle={-20} textAnchor="end" height={48} /><YAxis tick={{ fontSize: 10, fill: '#78827c' }} tickLine={false} axisLine={false} width={44} /><Tooltip /><Bar dataKey="demand" name="Demand" fill="#dceae3" radius={[3, 3, 0, 0]} /><Area dataKey="delivered" name="Delivered" type="monotone" stroke="#2a7d66" fill="#c8e5d6" strokeWidth={2} /></ComposedChart></ResponsiveContainer></div><div className="chart-legend"><span><i className="legend-dot demand-dot" />Demand</span><span><i className="legend-dot delivered-dot" />Delivered</span></div></section>
      <section className="panel chart-panel"><SectionTitle title="Request status" note="Current distribution" /><div className="status-chart"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={statuses} dataKey="count" nameKey="status" innerRadius={62} outerRadius={88} paddingAngle={3} stroke="none">{statuses.map((item, index) => <Cell key={item.status} fill={['#2d806b','#83b89c','#d49a49','#cf7258','#6c93aa'][index % 5]} />)}</Pie><Tooltip /></PieChart></ResponsiveContainer><div className="donut-total"><b>{fmt(stats?.requests)}</b><span>requests</span></div></div><div className="status-key">{statuses.slice(0, 4).map((item, index) => <div key={item.status}><i style={{ background: ['#2d806b','#83b89c','#d49a49','#cf7258'][index] }} />{item.status}<b>{item.count}</b></div>)}</div></section>
    </div>
    <div className="dashboard-grid lower-grid"><section className="panel chart-panel"><SectionTitle title="Fleet water capacity" note="Current water vs. assigned capacity" /><div className="chart-wrap fleet-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={utilization} margin={{ top: 8, right: 10, bottom: 2, left: 0 }}><CartesianGrid stroke="#e9eeea" vertical={false} /><XAxis dataKey="name" tick={{ fontSize: 10, fill: '#78827c' }} tickLine={false} axisLine={false} /><YAxis tick={{ fontSize: 10, fill: '#78827c' }} tickLine={false} axisLine={false} width={48} /><Tooltip /><Legend /><Bar dataKey="used" name="Allocated (L)" stackId="a" fill="#317d6a" /><Bar dataKey="remaining" name="Available (L)" stackId="a" fill="#dceae3" radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer></div></section><section className="panel activity-panel"><SectionTitle title="Recent activity" note="Latest operational events" action={<button className="text-button" onClick={() => onNavigate('reports')}>View report <ArrowRight size={13} /></button>} />{activities?.length ? <div className="activity-list">{activities.slice(0, 6).map((item) => <div className="activity-item" key={item.id}><span className="activity-mark"><Activity size={14} /></span><div><b>{item.message}</b><small>{shortDate(item.created_at)} · {item.kind}</small></div></div>)}</div> : <Empty message="No activity recorded yet." />}</section></div>
    <div className="operational-strip"><span className="pulse-dot" /><b>System operational</b><span>Database connected</span><span>Allocation engine ready</span><span className="sim-label">SIMULATED NETWORK</span></div>
  </>;
}

function Table({ columns, rows, empty, renderRow }) {
  return <div className="table-scroll"><table><thead><tr>{columns.map((col) => <th key={col}>{col}</th>)}</tr></thead><tbody>{rows.map(renderRow)}{!rows.length && <tr><td colSpan={columns.length}><Empty message={empty} /></td></tr>}</tbody></table></div>;
}

function Requests({ requests, search, setSearch, onAdd, isAdmin }) {
  const filtered = requests.filter((r) => `${r.area_name} ${r.status} ${r.urgency} ${r.id}`.toLowerCase().includes(search.toLowerCase()));
  return <><SectionTitle title="Water requests" note="Demand queue · searchable operational records" action={isAdmin&&<button className="button button-primary" onClick={onAdd}><Plus size={16} /> Register request</button>} /><div className="filter-row"><label className="search-box"><Search size={16} /><input placeholder="Search area, urgency or ID" value={search} onChange={(e) => setSearch(e.target.value)} /></label><span className="result-count">{filtered.length} records</span></div><section className="panel table-panel"><Table columns={['REQUEST','SERVICE AREA','DEMAND','REMAINING','URGENCY','WAITING','STATUS']} rows={filtered} empty="No requests match this search." renderRow={(r) => <tr key={r.id}><td className="id-cell">REQ-{String(r.id).padStart(4,'0')}</td><td><b>{r.area_name}</b><small className="cell-sub">{r.location}</small></td><td>{fmt(r.requested_litres)} L</td><td>{fmt(r.remaining_litres)} L</td><td><span className={`urgency urgency-${r.urgency.toLowerCase()}`}>{r.urgency}</span></td><td>{Math.max(0, Math.floor((Date.now() - new Date(r.created_at).getTime()) / 3600000))}h</td><td><Status>{r.status}</Status></td></tr>} /></section></>;
}

function Areas({ areas, search, setSearch, onAdd, onDelete, isAdmin }) {
  const [type, setType] = useState('All types');
  const filtered = areas.filter((a) => (type === 'All types' || a.type === type) && `${a.name} ${a.location} ${a.type}`.toLowerCase().includes(search.toLowerCase()));
  const AreaIcon = ({ type: areaType }) => areaType === 'Hospital' ? <Hospital size={15} /> : areaType === 'Apartment' ? <Building2 size={15} /> : <House size={15} />;
  return <><SectionTitle title="Service areas" note="Coverage, vulnerability and registered locations" action={isAdmin&&<button className="button button-primary" onClick={onAdd}><Plus size={16} /> Add service area</button>} /><div className="filter-row"><label className="search-box"><Search size={16} /><input placeholder="Search areas" value={search} onChange={(e) => setSearch(e.target.value)} /></label><select value={type} onChange={(e) => setType(e.target.value)}><option>All types</option><option>Hospital</option><option>Apartment</option><option>Individual House</option></select><span className="result-count">{filtered.length} areas</span></div><section className="panel table-panel"><Table columns={['AREA','TYPE','LOCATION','POPULATION','VULNERABILITY','CONTACT',...(isAdmin?['']:[])]} rows={filtered} empty="No service areas match." renderRow={(a) => <tr key={a.id}><td><b>{a.name}</b><small className="cell-sub">AREA-{String(a.id).padStart(3,'0')}</small></td><td><span className="type-label"><i style={{ color: TYPE_COLORS[a.type] }}><AreaIcon type={a.type} /></i>{a.type}</span></td><td>{a.location}</td><td>{fmt(a.population)}</td><td><div className="vulnerability"><span><i style={{ width: `${Math.min(100, a.vulnerability * 100)}%` }} /></span><b>{Math.round(a.vulnerability * 100)}%</b></div></td><td>{a.contact}</td>{isAdmin&&<td><button className="icon-button danger-hover" title="Delete area" onClick={() => onDelete(a)}><X size={15} /></button></td>}</tr>} /></section></>;
}

function Tankers({ tankers, onAdd, onDelete, isAdmin }) {
  return <><SectionTitle title="Tanker fleet" note="Vehicle capacity, water level and assignment state" action={isAdmin&&<button className="button button-primary" onClick={onAdd}><Plus size={16} /> Register tanker</button>} /><div className="fleet-summary"><div><Truck size={17} /><span>Fleet size</span><b>{tankers.length}</b></div><div><Waves size={17} /><span>Water available</span><b>{fmt(tankers.reduce((sum,t) => sum + Number(t.current_water),0))} L</b></div><div><Activity size={17} /><span>In operation</span><b>{tankers.filter((t) => ['Assigned','In Transit'].includes(t.status)).length}</b></div></div><section className="panel table-panel"><Table columns={['VEHICLE','SIZE','WATER LEVEL','DRIVER','CURRENT NODE','STATUS',...(isAdmin?['']:[])]} rows={tankers} empty="No tankers registered." renderRow={(t) => <tr key={t.id}><td><b>{t.vehicle}</b><small className="cell-sub">TANKER-{String(t.id).padStart(3,'0')}</small></td><td><span className="size-label">{t.size} · {fmt(t.capacity)} L</span></td><td><div className="water-level"><span><i style={{ width: `${Math.round(t.current_water / t.capacity * 100)}%` }} /></span><small>{fmt(t.current_water)} L</small></div></td><td>{t.driver}<small className="cell-sub">{t.contact}</small></td><td>{NODE_LABELS[t.road_node] || t.road_node}</td><td><Status>{t.status}</Status></td>{isAdmin&&<td><button className="icon-button danger-hover" title="Remove tanker" onClick={() => onDelete(t)}><X size={15} /></button></td>}</tr>} /></section></>;
}

function Allocation({ result, comparisons, weights, setWeights, onRun }) {
  const [strategy, setStrategy] = useState('FAIRNESS-FIRST');
  const [busy, setBusy] = useState(false);
  const cards = [{ id: 'FCFS', title: 'First come, first served', note: 'Chronological request order', code: '01' }, { id: 'NEAREST-FIRST', title: 'Nearest-first', note: 'Shortest eligible route first', code: '02' }, { id: 'FAIRNESS-FIRST', title: 'Fairness-first', note: 'Weighted need and urgency score', code: '03' }];
  async function run() { setBusy(true); await onRun(strategy); setBusy(false); }
  return <><SectionTitle title="Allocation engine" note="Run a strategy against pending demand and available tanker capacity" action={<span className="engine-badge"><span className="pulse-dot" /> C++ ENGINE READY</span>} /><div className="strategy-grid">{cards.map((card) => <button key={card.id} onClick={() => setStrategy(card.id)} className={`strategy-card ${strategy === card.id ? 'selected' : ''}`}><span className="strategy-number">{card.code}</span><span className="strategy-copy"><b>{card.title}</b><small>{card.note}</small></span>{strategy === card.id && <Check size={17} />}</button>)}</div><div className="allocation-layout"><section className="panel weight-panel"><SectionTitle title="Fairness weights" note="Applied to the fairness-first priority score" /><div className="weight-list">{[['waiting','Waiting time',weights.waiting],['demand','Unmet demand',weights.demand],['vulnerability','Area vulnerability',weights.vulnerability],['urgency','Request urgency',weights.urgency]].map(([key,label,amount]) => <label className="weight-row" key={key}><span>{label}</span><input type="number" min="0" max="1" step="0.05" value={amount} onChange={(e) => setWeights((old) => ({ ...old, [key]: Number(e.target.value) }))} /><span>{Math.round(amount * 100)}%</span></label>)}</div><div className={`weight-total ${Math.abs(Object.values(weights).reduce((a,b) => a+b,0)-1)<0.001 ? 'valid' : 'invalid'}`}><span>Weight total</span><b>{Object.values(weights).reduce((a,b) => a+b,0).toFixed(2)}</b><span>{Math.abs(Object.values(weights).reduce((a,b) => a+b,0)-1)<0.001 ? 'Valid' : 'Must equal 1.00'}</span></div><button className="button button-primary run-button" disabled={busy || Math.abs(Object.values(weights).reduce((a,b) => a+b,0)-1)>=0.001} onClick={run}><Zap size={16} />{busy ? 'Running C++ engine…' : `Run ${strategy.toLowerCase()} allocation`}</button></section><section className="panel compare-panel"><SectionTitle title="Strategy comparison" note="Capacity-aware evaluation on current eligible requests" /><div className="compare-metrics">{(comparisons || []).map((item) => <div key={item.strategy}><span>{item.strategy}</span><b>{fmt(item.water_delivered)} <small>L</small></b><small>{fmt(item.completed_requests)} fully served · J {Number(item.fairness_index).toFixed(2)}</small></div>)}</div><div className="compare-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={comparisons || []} margin={{ top: 4, right: 6, bottom: 4, left: -18 }}><CartesianGrid stroke="#e9eeea" vertical={false} /><XAxis dataKey="strategy" tick={{ fontSize: 10, fill: '#78827c' }} tickLine={false} axisLine={false} /><YAxis tick={{ fontSize: 10, fill: '#78827c' }} tickLine={false} axisLine={false} /><Tooltip /><Bar dataKey="fairness_index" name="Jain fairness index" fill="#3b8872" radius={[3,3,0,0]} /></BarChart></ResponsiveContainer></div></section></div>{result && <section className="panel result-panel"><SectionTitle title={`${result.strategy} run results`} note={`${result.assignments?.length || 0} delivery assignments created`} /><Table columns={['RANK','AREA / REQUEST','ASSIGNED TANKER','VOLUME','PRIORITY','DISTANCE','DELIVERY']} rows={result.assignments || []} empty="No eligible tanker capacity was available." renderRow={(a) => <tr key={a.delivery_id}><td>#{a.rank}</td><td><b>{a.area_name}</b><small className="cell-sub">REQ-{String(a.request_id).padStart(4,'0')}</small></td><td>TK-{String(a.tanker_id).padStart(3,'0')}</td><td>{fmt(a.amount_litres)} L</td><td>{a.priority_score ? Number(a.priority_score).toFixed(3) : '—'}</td><td>{Number(a.distance_km).toFixed(1)} km</td><td><Status>Pending</Status></td></tr>} /></section>}</>;
}

function FitBounds({ positions }) {
  const map = useMap();
  useEffect(() => { if (positions.length) map.fitBounds(positions, { padding: [32, 32], maxZoom: 12 }); }, [map, positions]);
  return null;
}

function Routes({ areas, tankers, deliveries, network, onTrack }) {
  const [selected, setSelected] = useState(null);
  const nodes = network?.nodes || [];
  const edges = network?.edges || [];
  const active = deliveries.filter((d) => ['Pending','In Transit','Paused'].includes(d.simulation_status));
  const positions = [...nodes.map((n) => [n.lat, n.lng]), ...areas.map((a) => [a.lat, a.lng])];
  return <><SectionTitle title="Routes & tracking" note="Illustrative Chennai road network · shortest path from the depot" action={<span className="sim-label">SIMULATED GPS TRACKING · DEMONSTRATION MODE</span>} /><div className="route-layout"><section className="panel map-panel"><div className="map-frame"><MapContainer center={[13.055, 80.215]} zoom={11} scrollWheelZoom className="fairflow-map"><TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />{edges.map((edge) => {const a=NODE_COORDS[edge.from_node],b=NODE_COORDS[edge.to_node];return a&&b?<Polyline key={`${edge.from_node}-${edge.to_node}`} positions={[a,b]} pathOptions={{ color:'#b6c8bc',weight:2,opacity:.75,dashArray:'5 7' }} />:null;})}{nodes.map((node) => <CircleMarker key={node.id} center={[node.lat,node.lng]} radius={node.id==='anna'?8:4} pathOptions={{ color:node.id==='anna'?'#216650':'#668c78',fillColor:node.id==='anna'?'#216650':'#a9c1b1',fillOpacity:1 }}><Popup>{node.id==='anna'?'Depot · ':''}{node.name}</Popup></CircleMarker>)}{areas.map((area) => <CircleMarker key={`area-${area.id}`} center={[area.lat,area.lng]} radius={7} pathOptions={{ color:TYPE_COLORS[area.type]||'#2f806b',fillColor:'#fff',fillOpacity:1,weight:3 }}><Popup><b>{area.name}</b><br />{area.type} · {area.location}</Popup></CircleMarker>)}{active.map((delivery) => {let route=[];try{route=JSON.parse(delivery.route_json).map((node)=>NODE_COORDS[node]).filter(Boolean);}catch{}return route.length>1?<Polyline key={`route-${delivery.id}`} positions={route} pathOptions={{color:delivery.simulation_status==='In Transit'?'#287d66':'#e0a54b',weight:4,opacity:.9}} />:null;})}<FitBounds positions={positions} /></MapContainer><div className="map-legend"><span><i className="legend-dot depot-dot" />Depot</span><span><i className="legend-dot area-dot" />Service area</span><span><i className="legend-dot route-dot" />Active route</span></div></div></section><aside className="panel route-side"><SectionTitle title="Delivery queue" note={`${active.length} active or scheduled`} />{active.length ? <div className="delivery-list">{active.map((delivery) => <article key={delivery.id} className={`delivery-card ${selected?.id===delivery.id?'active':''}`} onClick={() => setSelected(delivery)}><div className="delivery-top"><b>DEL-{String(delivery.id).padStart(4,'0')}</b><Status>{delivery.simulation_status}</Status></div><h3>{delivery.area_name}</h3><div className="delivery-meta"><span><Truck size={13} />{delivery.vehicle}</span><span><Waves size={13} />{fmt(delivery.amount_litres)} L</span></div><div className="progress-track"><i style={{ width: `${Math.round(delivery.progress*100)}%` }} /></div><small>{Math.round(delivery.progress*100)}% route complete · {Number(delivery.distance_km*(1-delivery.progress)).toFixed(1)} km remaining</small>{delivery.simulation_status==='Pending'&&<button className="button button-primary button-small" onClick={(event)=>{event.stopPropagation();onTrack('start',delivery.id);}}>Start delivery <ArrowRight size={13}/></button>}{delivery.simulation_status==='In Transit'&&<button className="button button-outline button-small" onClick={(event)=>{event.stopPropagation();onTrack('pause',delivery.id);}}>Pause simulation</button>}{delivery.simulation_status==='Paused'&&<button className="button button-primary button-small" onClick={(event)=>{event.stopPropagation();onTrack('resume',delivery.id);}}>Resume delivery <ArrowRight size={13}/></button>}</article>)}</div>:<Empty message="No active deliveries. Run allocation to schedule a route." />}</aside></div><div className="route-footnote"><span className="pulse-dot" />The road graph and GPS movement are simulated for demonstration. No live traffic or vehicle GPS is connected.</div></>;
}

function Reports({ stats, analytics, comparisons }) {
  const distribution = analytics?.distribution || [];
  const served = Number(stats?.water_delivered || 0);
  const demanded = Number(stats?.water_demanded || 0);
  async function exportCsv() {
    try {
      const csv = await api('/reports/export');
      const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
      const link = document.createElement('a');
      link.href = url;
      link.download = 'fairflow-report.csv';
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Could not export FairFlow report:', error);
    }
  }
  return <><SectionTitle title="Performance & reports" note="Operational results calculated from this browser's saved records" action={
    <>
      <a className="button button-outline" href="#export" onClick={(event) => { event.preventDefault(); exportCsv(); }}>
        <ArrowDownToLine size={15} />Export CSV
      </a>
      <button className="button button-outline" onClick={()=>window.print()}>Print report</button>
    </>
  } /><div className="report-stats"><div><span>Total requests</span><b>{fmt(stats?.requests)}</b></div><div><span>Served</span><b>{fmt(stats?.completed)}</b></div><div><span>Water delivered</span><b>{fmt(served)} <small>L</small></b></div><div><span>Unmet demand</span><b>{fmt(stats?.unmet_demand)} <small>L</small></b></div><div><span>Demand coverage</span><b>{demanded?Math.round(served/demanded*100):0}<small>%</small></b></div><div><span>Available fleet</span><b>{fmt(stats?.available_tankers)}</b></div></div><div className="dashboard-grid report-grid"><section className="panel chart-panel"><SectionTitle title="Water delivered by area type" note="Litres confirmed complete"/><div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><BarChart data={distribution}><CartesianGrid stroke="#e9eeea" vertical={false}/><XAxis dataKey="type" tick={{fontSize:10,fill:'#78827c'}} tickLine={false} axisLine={false}/><YAxis tick={{fontSize:10,fill:'#78827c'}} tickLine={false} axisLine={false}/><Tooltip/><Bar dataKey="delivered" name="Delivered (L)" fill="#388671" radius={[4,4,0,0]}/></BarChart></ResponsiveContainer></div></section><section className="panel chart-panel"><SectionTitle title="Allocation strategy comparison" note="Current demand and fleet snapshot"/><div className="compare-chart report-compare"><ResponsiveContainer width="100%" height="100%"><BarChart data={comparisons||[]}><CartesianGrid stroke="#e9eeea" vertical={false}/><XAxis dataKey="strategy" tick={{fontSize:9,fill:'#78827c'}} tickLine={false} axisLine={false}/><YAxis tick={{fontSize:10,fill:'#78827c'}} tickLine={false} axisLine={false}/><Tooltip/><Legend/><Bar dataKey="water_delivered" name="Delivered litres" fill="#2c7d68" radius={[3,3,0,0]}/><Bar dataKey="fairness_index" name="Jain index" fill="#daa452" radius={[3,3,0,0]}/></BarChart></ResponsiveContainer></div></section></div><section className="panel report-note"><div className="report-note-icon"><Gauge size={18}/></div><div><b>Measurement notes</b><p>Delivery totals count completed simulations only. Fairness uses Jain's index over simulated per-request allocation for the current pending queue; zero-demand denominators are handled as 0.</p></div></section></>;
}

function ProjectInfo() {
  const modules = [['01','Demand registration','Service areas, urgency-weighted requests and auditable records.'],['02','Equitable allocation','FCFS, nearest-first and weighted fairness-first with capacity limits.'],['03','Route optimization','Priority-queue Dijkstra over an illustrative Chennai road graph.'],['04','Evaluation & reporting','Browser-saved demand, completion, utilization and Jain fairness metrics.']];
  return <><SectionTitle title="About FairFlow" note="An intelligent framework for equitable water distribution and tanker allocation optimization"/><section className="project-intro"><span className="eyebrow">ACADEMIC ENGINEERING PROJECT</span><h2>Better allocation starts<br/>with a clearer picture.</h2><p>FairFlow models a practical municipal water response workflow: capture demand, prioritize need, assign constrained fleet capacity and evaluate the results. It is designed to make the decisions visible, explainable and repeatable.</p></section><div className="module-grid">{modules.map(([n,title,copy])=><article key={n}><span>{n}</span><h3>{title}</h3><p>{copy}</p></article>)}</div><section className="panel stack-panel"><SectionTitle title="Runtime architecture" note="This browser build works independently of the optional C++ backend"/><div className="architecture-row"><span>React + Vite</span><ArrowRight size={16}/><span>Local service</span><ArrowRight size={16}/><span>Browser storage</span></div><div className="architecture-detail"><span>FCFS · fairness priority queue</span><span>Dijkstra route graph</span><span>Browser password hashing</span><span>Persistent local simulation</span></div></section><div className="limitations"><CircleHelp size={17}/><p><b>Local demonstration:</b> accounts and records are saved in this browser profile. Clearing browser site data removes them. The C++/SQLite source is included but is not used by this running app; the Chennai road graph and GPS movement are simulated.</p></div></>;
}

function Dialog({ kind, areas, onClose, onSave }) {
  const fields = kind === 'area' ? [['name','Area name','text'],['type','Area type','select'],['location','Location','text'],['road_node','Road network node','select'],['lat','Latitude','number'],['lng','Longitude','number'],['population','Population','number'],['vulnerability','Vulnerability (0–1)','number'],['contact','Contact','text']] : kind === 'request' ? [['area_id','Service area','select'],['requested_litres','Water quantity (litres)','number'],['urgency','Urgency','select'],['vulnerability','Vulnerability (0–1)','number'],['remarks','Remarks','text']] : [['vehicle','Vehicle registration','text'],['size','Tanker size','select'],['current_water','Current water (litres)','number'],['driver','Driver name','text'],['contact','Driver contact','text'],['road_node','Current network node','select']];
  const [form,setForm] = useState(kind==='request'?{urgency:'Normal',vulnerability:0.5}:kind==='tanker'?{size:'Small',current_water:6000,road_node:'anna'}:{type:'Apartment',road_node:'anna',lat:13.05,lng:80.22,population:100,vulnerability:0.5});
  const [error,setError] = useState('');
  const selects = { type:['Apartment','Individual House','Hospital'], road_node:Object.entries(NODE_LABELS).map(([id,name])=>({value:id,label:name})), size:['Small','Large'], area_id:areas.map((a)=>({value:a.id,label:a.name})), urgency:['Normal','Medium','High','Critical'] };
  async function submit(event){event.preventDefault();setError('');try{await onSave(kind,form);onClose();}catch(e){setError(e.message);}}
  return <div className="dialog-backdrop" onMouseDown={(e)=>e.target===e.currentTarget&&onClose()}><form className="dialog" onSubmit={submit}><div className="dialog-head"><div><span className="eyebrow">NEW RECORD</span><h2>{kind==='area'?'Register service area':kind==='request'?'Register water request':'Register tanker'}</h2></div><button type="button" className="icon-button" onClick={onClose}><X size={18}/></button></div><div className="dialog-fields">{fields.map(([name,label,type])=><label key={name}>{label}{type==='select'?<select required value={form[name]??''} onChange={(e)=>setForm({...form,[name]:e.target.value})}><option value="" disabled>Select {label.toLowerCase()}</option>{selects[name].map((item)=>typeof item==='string'?<option key={item}>{item}</option>:<option key={item.value} value={item.value}>{item.label}</option>)}</select>:<input required={name!=='contact'} type={type} min={type==='number'&&name==='vulnerability'?0:undefined} max={name==='vulnerability'?1:undefined} step={name==='vulnerability'?'0.01':type==='number'?'any':undefined} value={form[name]??''} onChange={(e)=>setForm({...form,[name]:type==='number'?Number(e.target.value):e.target.value})}/>}</label>)}</div>{error&&<div className="form-error">{error}</div>}<div className="dialog-actions"><button type="button" className="button button-outline" onClick={onClose}>Cancel</button><button className="button button-primary"><Plus size={15}/> Save record</button></div></form></div>;
}

export default function App() {
  const [user,setUser] = useState(null);
  const [page,setPage] = useState('overview');
  const [mobileOpen,setMobileOpen] = useState(false);
  const [authError,setAuthError] = useState('');
  const [error,setError] = useState('');
  const [loading,setLoading] = useState(false);
  const [stats,setStats] = useState({});
  const [analytics,setAnalytics] = useState({});
  const [areas,setAreas] = useState([]);
  const [requests,setRequests] = useState([]);
  const [tankers,setTankers] = useState([]);
  const [activities,setActivities] = useState([]);
  const [network,setNetwork] = useState(null);
  const [deliveries,setDeliveries] = useState([]);
  const [comparisons,setComparisons] = useState([]);
  const [result,setResult] = useState(null);
  const [weights,setWeights] = useState({waiting:.25,demand:.3,vulnerability:.25,urgency:.2});
  const [search,setSearch] = useState('');
  const [dialog,setDialog] = useState('');

  async function loadData(){
    setError('');
    try {
      const [newStats,newAnalytics,newAreas,newRequests,newTankers,newActivities,newNetwork,newDeliveries,newComparisons,newSettings] = await Promise.all([
        api('/dashboard/stats'),api('/dashboard/analytics'),api('/areas'),api('/requests'),api('/tankers'),api('/activity'),api('/routes/network'),api('/tracking/active'),api('/allocation/compare'),api('/settings'),
      ]);
      setStats(newStats);setAnalytics(newAnalytics);setAreas(newAreas);setRequests(newRequests);setTankers(newTankers);setActivities(newActivities);setNetwork(newNetwork);setDeliveries(newDeliveries);setComparisons(newComparisons);
      const settings=Object.fromEntries(newSettings.map((item)=>[item.key,item.value]));
      if(settings.weight_waiting)setWeights({waiting:Number(settings.weight_waiting),demand:Number(settings.weight_demand),vulnerability:Number(settings.weight_vulnerability),urgency:Number(settings.weight_urgency)});
    } catch (e) { setError(e.message); }
  }
  useEffect(()=>{
    const token=getToken();if(!token)return;
    api('/auth/me').then(setUser).catch(()=>setToken(null));
  },[]);
  useEffect(()=>{if(!user)return;loadData();const interval=setInterval(loadData,5000);return()=>clearInterval(interval);},[user]);
  async function login(email,password,role,pin){setAuthError('');try{const result=await api('/auth/login',{method:'POST',body:{email,password,role,pin}});setToken(result.token);setUser(result.user);}catch(e){setAuthError(e.message);}}
  async function register(email,password,role,pin){setAuthError('');try{const result=await api('/auth/register',{method:'POST',body:{email,password,role,pin}});setToken(result.token);setUser(result.user);}catch(e){setAuthError(e.message);}}
  async function logout(){try{await api('/auth/logout',{method:'POST'});}catch{}setToken(null);setUser(null);}
  async function saveRecord(kind,form){await api(`/${kind==='area'?'areas':kind==='request'?'requests':'tankers'}`,{method:'POST',body:form});await loadData();}
  async function removeRecord(kind,item){if(!window.confirm(`Remove ${kind==='area'?item.name:item.vehicle}?`))return;try{await api(`/${kind==='area'?'areas':'tankers'}/${item.id}`,{method:'DELETE'});await loadData();}catch(e){setError(e.message);}}
  async function runAllocation(strategy){try{const allocation=await api('/allocation/run',{method:'POST',body:{strategy,weight_waiting:weights.waiting,weight_demand:weights.demand,weight_vulnerability:weights.vulnerability,weight_urgency:weights.urgency}});setResult(allocation);await loadData();}catch(e){setError(e.message);}}
  async function track(action,id){try{await api(`/tracking/${action}`,{method:'POST',body:{delivery_id:id}});await loadData();}catch(e){setError(e.message);}}
  async function navigate(id){setPage(id);setSearch('');setMobileOpen(false);}
  if(!user)return <Login onLogin={login} onRegister={register} error={authError}/>;
  const pageLabels={...Object.fromEntries(NAV.map((item)=>[item.id,item.label])),project:'Project information',settings:'System settings'};
  const isAdmin=user.role==='admin';
  const visibleNav=isAdmin?NAV:NAV.filter((item)=>['overview','requests','routes'].includes(item.id));
  return <div className="app-shell"><aside className={`sidebar ${mobileOpen?'sidebar-open':''}`}><Brand/><div className="workspace-label">OPERATIONS</div><nav className="side-nav">{visibleNav.map(({id,label,icon:Icon})=><button key={id} className={page===id?'active':''} onClick={()=>navigate(id)}><Icon size={17}/><span>{label}</span>{id==='routes'&&deliveries.some((d)=>d.simulation_status==='In Transit')&&<i className="nav-live"/>}</button>)}</nav><div className="sidebar-bottom"><div className="sidebar-status"><span className="pulse-dot"/><div><b>API connected</b><small>SQLite · C++17</small></div></div>{isAdmin&&<><button className="side-link" onClick={()=>navigate('settings')}><Settings size={16}/>System settings</button><button className="side-link" onClick={()=>navigate('project')}><CircleHelp size={16}/>About FairFlow</button></>}<div className="profile-row"><div className="avatar">{user.username?.slice(0,1).toUpperCase()}</div><div><b>{user.username}</b><small>{user.role}</small></div><button className="icon-button" title="Sign out" onClick={logout}><LogOut size={16}/></button></div></div></aside><div className="app-main"><header className="topbar"><button className="icon-button mobile-menu" onClick={()=>setMobileOpen(!mobileOpen)}><Menu size={19}/></button><div className="breadcrumbs">FairFlow <span>/</span> <b>{pageLabels[page]||'Overview'}</b></div><div className="topbar-right"><span className="topbar-live"><i className="pulse-dot"/>Live data</span><button className="icon-button notification-button" title="Recent activity" onClick={()=>navigate('overview')}><Bell size={17}/>{activities.length>0&&<i/>}</button><span className="topbar-date">{new Date().toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'})}</span></div></header><main className="page-content">{error&&<div className="error-banner"><span>{error}</span><button className="icon-button" onClick={()=>setError('')}><X size={15}/></button></div>}{loading&&<div className="loading-line"/>}{page==='overview'&&<Overview stats={stats} analytics={analytics} activities={activities} onNavigate={navigate}/ >}{page==='requests'&&<Requests requests={requests} search={search} setSearch={setSearch} isAdmin={isAdmin} onAdd={()=>setDialog('request')}/ >}{page==='areas'&&<Areas areas={areas} search={search} setSearch={setSearch} isAdmin={isAdmin} onAdd={()=>setDialog('area')} onDelete={(item)=>removeRecord('area',item)}/ >}{page==='tankers'&&<Tankers tankers={tankers} isAdmin={isAdmin} onAdd={()=>setDialog('tanker')} onDelete={(item)=>removeRecord('tanker',item)}/ >}{page==='allocation'&&<Allocation result={result} comparisons={comparisons} weights={weights} setWeights={setWeights} onRun={runAllocation}/ >}{page==='routes'&&<Routes areas={areas} tankers={tankers} deliveries={deliveries} network={network} onTrack={track}/ >}{page==='reports'&&<Reports stats={stats} analytics={analytics} comparisons={comparisons}/ >}{page==='project'&&isAdmin&&<ProjectInfo/>}{page==='settings'&&isAdmin&&<SettingsPage weights={weights} setWeights={setWeights} onSaved={loadData}/>}</main><footer className="app-footer"><span>FAIRFLOW · WATER DISTRIBUTION OPERATIONS</span><span>Demonstration network · Chennai, India</span></footer></div>{dialog&&<Dialog kind={dialog} areas={areas} onClose={()=>setDialog('')} onSave={saveRecord}/>}</div>;
}

function SettingsPage({weights,setWeights,onSaved}) {
  const [speed,setSpeed]=useState('0.18');const [message,setMessage]=useState('');
  useEffect(()=>{api('/settings').then((items)=>{const settings=Object.fromEntries(items.map((item)=>[item.key,item.value]));if(settings.simulation_speed)setSpeed(settings.simulation_speed);}).catch(()=>{});},[]);
  async function save(){const total=Object.values(weights).reduce((a,b)=>a+b,0);if(Math.abs(total-1)>.001){setMessage('Fairness weights must add up to 1.00');return;}try{await api('/settings',{method:'PUT',body:{simulation_speed:speed,weight_waiting:weights.waiting,weight_demand:weights.demand,weight_vulnerability:weights.vulnerability,weight_urgency:weights.urgency}});setMessage('Settings saved in this browser.');onSaved();}catch(e){setMessage(e.message);}}
  async function reset(){if(!window.confirm('Reset all operational records and restore the original demonstration dataset?'))return;try{await api('/demo/reset',{method:'POST'});setMessage('Demonstration data restored.');onSaved();}catch(e){setMessage(e.message);}}
  return <><SectionTitle title="System settings" note="Control fairness priorities, simulation pacing and demonstration data"/><div className="settings-grid"><section className="panel settings-panel"><SectionTitle title="Fairness weights" note="All weights must sum to 1.00"/>{[['waiting','Waiting time'],['demand','Unmet demand'],['vulnerability','Area vulnerability'],['urgency','Request urgency']].map(([key,label])=><label className="setting-row" key={key}><span>{label}</span><input type="number" min="0" max="1" step="0.05" value={weights[key]} onChange={(e)=>setWeights({...weights,[key]:Number(e.target.value)})}/></label>)}<label className="setting-row"><span>Simulation speed (% route / second)</span><input type="number" min="0.02" max="1" step="0.02" value={speed} onChange={(e)=>setSpeed(e.target.value)}/></label><div className="settings-actions"><button className="button button-primary" onClick={save}><Check size={15}/> Save settings</button></div>{message&&<div className="settings-message">{message}</div>}</section><section className="panel settings-panel"><SectionTitle title="Demonstration data" note="Restore the original seeded scenario"/><p className="settings-copy">Reset removes saved requests, allocations and delivery records, then recreates 10 service areas, 15 requests, 8 tankers and the illustrative road network.</p><button className="button button-outline reset-button" onClick={reset}>Reset demonstration data</button><div className="settings-rule"/><SectionTitle title="Application" note="Academic engineering project"/><div className="about-points"><span>Backend <b>C++17 · cpp-httplib</b></span><span>Storage <b>SQLite</b></span><span>Routing <b>Dijkstra · priority queue</b></span><span>Tracking <b>Simulated GPS only</b></span></div></section></div></>;
}
