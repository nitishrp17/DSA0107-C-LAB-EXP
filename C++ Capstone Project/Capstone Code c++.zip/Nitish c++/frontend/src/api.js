const TOKEN_KEY = 'fairflow-token';
const DATA_KEY = 'fairflow-local-data-v1';
const SESSION_KEY = 'fairflow-local-session-v1';
const PIN = '060506';

const nodes = [
  { id: 'anna', name: 'Anna Nagar', lat: 13.085, lng: 80.2101 },
  { id: 'ambattur', name: 'Ambattur', lat: 13.1143, lng: 80.1548 },
  { id: 'kilpauk', name: 'Kilpauk', lat: 13.0827, lng: 80.238 },
  { id: 'egmore', name: 'Egmore', lat: 13.0732, lng: 80.2609 },
  { id: 'perambur', name: 'Perambur', lat: 13.1161, lng: 80.2336 },
  { id: 'tnagar', name: 'T. Nagar', lat: 13.0418, lng: 80.2341 },
  { id: 'guindy', name: 'Guindy', lat: 13.0067, lng: 80.2206 },
  { id: 'adyar', name: 'Adyar', lat: 13.0012, lng: 80.2565 },
  { id: 'velachery', name: 'Velachery', lat: 12.975, lng: 80.2212 },
  { id: 'tambaram', name: 'Tambaram', lat: 12.9249, lng: 80.1 },
];

const edges = [
  ['anna', 'ambattur', 8.2], ['anna', 'kilpauk', 5.1], ['ambattur', 'perambur', 9],
  ['kilpauk', 'perambur', 5.2], ['kilpauk', 'egmore', 3.6], ['perambur', 'egmore', 6.1],
  ['egmore', 'tnagar', 6.4], ['tnagar', 'guindy', 5.7], ['guindy', 'adyar', 7.5],
  ['guindy', 'velachery', 5], ['adyar', 'velachery', 5.4], ['velachery', 'tambaram', 13.2],
  ['guindy', 'tambaram', 19.5], ['tnagar', 'adyar', 8.2], ['anna', 'egmore', 9.4],
].map(([from_node, to_node, distance_km]) => ({ from_node, to_node, distance_km }));

const seedAreas = [
  ['Sundaram Apartments', 'Apartment', 'Anna Nagar', 13.085, 80.210, 420, .42, '044-25011001', 'anna'],
  ['Green Park Residency', 'Apartment', 'Ambattur', 13.114, 80.155, 280, .63, '044-25011002', 'ambattur'],
  ["St. Mary's Medical Centre", 'Hospital', 'Kilpauk', 13.083, 80.238, 190, .88, '044-25011003', 'kilpauk'],
  ['Egmore Community Homes', 'Individual House', 'Egmore', 13.073, 80.261, 85, .71, '044-25011004', 'egmore'],
  ['Perambur Lakeview', 'Apartment', 'Perambur', 13.116, 80.234, 360, .56, '044-25011005', 'perambur'],
  ["Kaveri Children's Hospital", 'Hospital', 'T. Nagar', 13.042, 80.234, 145, .94, '044-25011006', 'tnagar'],
  ['Guindy Worker Colony', 'Individual House', 'Guindy', 13.007, 80.221, 120, .77, '044-25011007', 'guindy'],
  ['Adyar Cooperative Homes', 'Apartment', 'Adyar', 13.001, 80.257, 310, .39, '044-25011008', 'adyar'],
  ['Velachery Relief Centre', 'Hospital', 'Velachery', 12.975, 80.221, 160, .91, '044-25011009', 'velachery'],
  ['Tambaram South Homes', 'Individual House', 'Tambaram', 12.925, 80.1, 95, .69, '044-25011010', 'tambaram'],
].map(([name, type, location, lat, lng, population, vulnerability, contact, road_node], index) => ({
  id: index + 1, name, type, location, lat, lng, population, vulnerability, contact, road_node,
  created_at: new Date().toISOString(),
}));

const seedRequests = [
  [1, 9000, 'Critical', .94, 'Emergency ward and patient care', 45],
  [2, 6200, 'High', .63, 'Storage is below one day', 42],
  [3, 11000, 'Critical', .96, 'Clinical water reserve', 39],
  [4, 4200, 'Medium', .71, 'Community supply request', 36],
  [5, 7500, 'High', .56, 'Apartment block reserve', 33],
  [6, 8000, 'Critical', .91, 'Patient services', 30],
  [7, 5300, 'High', .77, 'Worker housing supply', 27],
  [8, 6800, 'Normal', .39, 'Scheduled top-up', 24],
  [9, 12000, 'Critical', .93, 'Hospital reserve', 21],
  [10, 4500, 'Medium', .69, 'Household request', 18],
  [1, 3800, 'Medium', .42, 'Additional household demand', 15],
  [2, 5100, 'Normal', .63, 'Routine request', 12],
  [4, 6400, 'High', .71, 'Low stored supply', 9],
  [5, 5800, 'Medium', .56, 'Apartment block request', 6],
  [8, 4300, 'Normal', .39, 'Scheduled delivery', 3],
].map(([area_id, requested_litres, urgency, vulnerability, remarks, hours], index) => ({
  id: index + 1, area_id, requested_litres, remaining_litres: requested_litres, delivered_litres: 0,
  urgency, vulnerability, created_at: new Date(Date.now() - hours * 3600000).toISOString(), remarks, status: 'Pending',
}));

const seedTankers = Array.from({ length: 8 }, (_, index) => {
  const size = [0, 1, 3, 5, 7].includes(index) ? 'Large' : 'Small';
  const capacity = size === 'Large' ? 12000 : 6000;
  return {
    id: index + 1, vehicle: `TN 01 AB ${2201 + index}`, size, capacity, current_water: capacity,
    driver: ['R. Kumar', 'S. Devi', 'M. Arul', 'P. Selvam', 'K. Meena', 'V. Ravi', 'A. Balan', 'J. Rani'][index],
    contact: `900000000${index + 1}`, status: 'Available', road_node: 'anna', assigned_area_id: null,
  };
});

function initialData() {
  return {
    users: [], areas: seedAreas, requests: seedRequests, tankers: seedTankers,
    allocations: [], deliveries: [], activities: [{ id: 1, kind: 'system', message: 'Local FairFlow workspace initialized', created_at: new Date().toISOString() }],
    settings: { simulation_speed: '0.12', depot_node: 'anna', weight_waiting: '0.25', weight_demand: '0.30', weight_vulnerability: '0.25', weight_urgency: '0.20' },
  };
}

function loadData() {
  try {
    const stored = localStorage.getItem(DATA_KEY);
    if (!stored) return initialData();
    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed.users) || !Array.isArray(parsed.areas)) return initialData();
    return { ...initialData(), ...parsed };
  } catch {
    return initialData();
  }
}

let state = loadData();
function persist() { localStorage.setItem(DATA_KEY, JSON.stringify(state)); }
function idFor(list) { return list.reduce((max, row) => Math.max(max, Number(row.id) || 0), 0) + 1; }
function log(kind, message) {
  state.activities.unshift({ id: idFor(state.activities), kind, message, created_at: new Date().toISOString() });
  state.activities = state.activities.slice(0, 100);
}
function areaById(id) { return state.areas.find((area) => Number(area.id) === Number(id)); }
function enrichedRequests() {
  return state.requests.map((request) => {
    const area = areaById(request.area_id) || {};
    return { ...request, area_name: area.name || 'Removed area', area_type: area.type || '', location: area.location || '', road_node: area.road_node || 'anna' };
  }).sort((a, b) => a.created_at.localeCompare(b.created_at));
}
function route(from, to) {
  if (from === to) return { nodes: [from], distance_km: 0 };
  const distances = new Map([[from, 0]]);
  const previous = new Map();
  const queue = new Set(nodes.map((node) => node.id));
  while (queue.size) {
    let current = null;
    for (const candidate of queue) if (distances.has(candidate) && (current === null || distances.get(candidate) < distances.get(current))) current = candidate;
    if (current === null) break;
    queue.delete(current);
    if (current === to) break;
    for (const edge of edges) {
      const next = edge.from_node === current ? edge.to_node : edge.to_node === current ? edge.from_node : null;
      if (!next || !queue.has(next)) continue;
      const distance = distances.get(current) + edge.distance_km;
      if (distance < (distances.get(next) ?? Infinity)) {
        distances.set(next, distance);
        previous.set(next, current);
      }
    }
  }
  if (!distances.has(to)) throw new Error('No route connects the selected nodes.');
  const path = [to];
  while (path[0] !== from) path.unshift(previous.get(path[0]));
  return { nodes: path, distance_km: distances.get(to) };
}

async function passwordDigest(password, salt) {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: encoder.encode(salt), iterations: 120000, hash: 'SHA-256' }, key, 256);
  return [...new Uint8Array(bits)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
}
function createToken(user) {
  const token = `${crypto.randomUUID()}-${Date.now()}`;
  localStorage.setItem(SESSION_KEY, JSON.stringify({ token, userId: user.id }));
  setToken(token);
  return token;
}
function activeUser() {
  try {
    const session = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
    if (!session || session.token !== getToken()) return null;
    return state.users.find((user) => user.id === session.userId) || null;
  } catch { return null; }
}
function publicUser(user) {
  return { id: user.id, username: user.email, email: user.email, role: user.role };
}
function requireAdmin() {
  if (activeUser()?.role !== 'admin') throw new Error('Administrator access required.');
}
function requestStatusCounts() {
  const counts = new Map();
  for (const request of state.requests) counts.set(request.status, (counts.get(request.status) || 0) + 1);
  return [...counts].map(([status, count]) => ({ status, count }));
}
function dashboardStats() {
  const activeStatuses = ['Pending', 'Allocated', 'In Transit', 'Partially Delivered'];
  return {
    areas: state.areas.length,
    requests: state.requests.length,
    pending: state.requests.filter((item) => activeStatuses.includes(item.status)).length,
    completed: state.requests.filter((item) => item.status === 'Delivered').length,
    available_tankers: state.tankers.filter((item) => item.status === 'Available').length,
    active_tankers: state.tankers.filter((item) => ['Assigned', 'In Transit'].includes(item.status)).length,
    water_demanded: state.requests.reduce((sum, item) => sum + Number(item.requested_litres), 0),
    water_delivered: state.requests.reduce((sum, item) => sum + Number(item.delivered_litres), 0),
    unmet_demand: state.requests.reduce((sum, item) => sum + Number(item.remaining_litres), 0),
    recent_activity: state.activities.slice(0, 8),
  };
}
function analytics() {
  return {
    demand_by_area: state.areas.map((area) => {
      const requests = state.requests.filter((item) => Number(item.area_id) === Number(area.id));
      return { name: area.name, type: area.type, demand: requests.reduce((sum, item) => sum + Number(item.requested_litres), 0), delivered: requests.reduce((sum, item) => sum + Number(item.delivered_litres), 0) };
    }),
    statuses: requestStatusCounts(),
    distribution: ['Hospital', 'Apartment', 'Individual House'].map((type) => ({ type, delivered: state.areas.filter((area) => area.type === type).reduce((sum, area) => sum + state.requests.filter((request) => Number(request.area_id) === Number(area.id)).reduce((total, request) => total + Number(request.delivered_litres), 0), 0) })),
    utilization: state.tankers.map(({ vehicle, size, capacity, current_water, status }) => ({ vehicle, size, capacity, current_water, status })),
  };
}
function touchDeliveries() {
  const now = Date.now();
  for (const delivery of state.deliveries) {
    if (delivery.simulation_status !== 'In Transit') continue;
    const elapsed = Math.max(1, (now - (delivery.last_tick || now)) / 1000);
    delivery.progress = Math.min(1, delivery.progress + elapsed * Number(state.settings.simulation_speed || .12));
    delivery.last_tick = now;
    if (delivery.progress >= 1) {
      delivery.progress = 1;
      delivery.simulation_status = 'Delivered';
      delivery.status = 'Delivered';
      const request = state.requests.find((item) => item.id === delivery.request_id);
      if (request) {
        request.delivered_litres += delivery.amount_litres;
        request.remaining_litres = Math.max(0, request.requested_litres - request.delivered_litres);
        request.status = request.remaining_litres === 0 ? 'Delivered' : 'Partially Delivered';
      }
      const tanker = state.tankers.find((item) => item.id === delivery.tanker_id);
      if (tanker) { tanker.status = 'Available'; tanker.assigned_area_id = null; }
      log('delivery', `Delivery #${delivery.id} completed`);
    }
  }
  persist();
}
function comparison() {
  const pending = state.requests.filter((item) => ['Pending', 'Partially Delivered'].includes(item.status) && item.remaining_litres > 0);
  const weights = {
    waiting: Number(state.settings.weight_waiting || .25), demand: Number(state.settings.weight_demand || .3),
    vulnerability: Number(state.settings.weight_vulnerability || .25), urgency: Number(state.settings.weight_urgency || .2),
  };
  return ['FCFS', 'NEAREST-FIRST', 'FAIRNESS-FIRST'].map((strategy) => {
    const requests = [...pending];
    if (strategy === 'NEAREST-FIRST') requests.sort((a, b) => route('anna', areaById(a.area_id)?.road_node || 'anna').distance_km - route('anna', areaById(b.area_id)?.road_node || 'anna').distance_km);
    if (strategy === 'FAIRNESS-FIRST') {
      const maxWait = Math.max(1, ...requests.map((item) => (Date.now() - new Date(item.created_at).getTime()) / 3600000));
      const maxDemand = Math.max(1, ...requests.map((item) => item.remaining_litres));
      const urgencyScore = { Normal: .25, Medium: .5, High: .75, Critical: 1 };
      requests.sort((a, b) => {
        const score = (item) => weights.waiting * Math.min(1, (Date.now() - new Date(item.created_at).getTime()) / 3600000 / maxWait)
          + weights.demand * item.remaining_litres / maxDemand + weights.vulnerability * item.vulnerability
          + weights.urgency * (urgencyScore[item.urgency] || .25);
        return score(b) - score(a);
      });
    }
    const tankers = state.tankers.filter((item) => item.status === 'Available' && item.current_water > 0).map((item) => ({ ...item }));
    let water = 0; let completed = 0; let distance = 0;
    requests.forEach((request, index) => {
      const tanker = tankers[index];
      if (!tanker) return;
      const amount = Math.min(request.remaining_litres, tanker.current_water);
      water += amount;
      if (amount >= request.remaining_litres) completed += 1;
      distance += route(tanker.road_node, areaById(request.area_id)?.road_node || 'anna').distance_km;
      tanker.current_water -= amount;
    });
    const total = requests.reduce((sum, item) => sum + item.remaining_litres, 0);
    const amounts = state.areas.map((area) => requests.filter((item) => Number(item.area_id) === Number(area.id)).reduce((sum, item) => sum + Math.min(item.remaining_litres, 12000), 0));
    const sum = amounts.reduce((a, b) => a + b, 0);
    const squares = amounts.reduce((a, b) => a + b * b, 0);
    return { strategy, water_delivered: water, completed_requests: completed, average_wait_hours: 0, travel_distance_km: distance, unmet_demand: Math.max(0, total - water), fairness_index: squares ? sum * sum / (amounts.length * squares) : 0 };
  });
}
function makeCsv() {
  const quote = (input) => `"${String(input ?? '').replaceAll('"', '""')}"`;
  const lines = [['request_id', 'area', 'requested_litres', 'delivered_litres', 'unmet_litres', 'urgency', 'status', 'created_at']];
  for (const request of enrichedRequests()) lines.push([request.id, request.area_name, request.requested_litres, request.delivered_litres, request.remaining_litres, request.urgency, request.status, request.created_at]);
  return lines.map((row) => row.map(quote).join(',')).join('\r\n');
}
function nextNode(id) { return idFor(state[id]); }

export function getToken() { return localStorage.getItem(TOKEN_KEY); }
export function setToken(token) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(SESSION_KEY); }
}

export async function api(path, options = {}) {
  const method = (options.method || 'GET').toUpperCase();
  const body = typeof options.body === 'string' ? JSON.parse(options.body || '{}') : (options.body || {});
  touchDeliveries();

  if (path === '/auth/register' && method === 'POST') {
    const email = String(body.email || '').trim().toLowerCase();
    const role = body.role;
    if (!email.includes('@') || !email.includes('.')) throw new Error('Enter a valid email address.');
    if (String(body.password || '').length < 8) throw new Error('Password must be at least 8 characters.');
    if (!['admin', 'operator'].includes(role)) throw new Error('Choose Admin or Operator.');
    if (role === 'admin' && body.pin !== PIN) throw new Error('Administrator PIN is incorrect.');
    if (state.users.some((user) => user.email === email)) throw new Error('An account with this email already exists. Sign in instead.');
    const salt = crypto.randomUUID();
    const user = { id: idFor(state.users), email, role, salt, passwordHash: await passwordDigest(body.password, salt) };
    state.users.push(user);
    const token = createToken(user);
    log('auth', `${email} created a ${role} account`);
    persist();
    return { token, user: publicUser(user) };
  }

  if (path === '/auth/login' && method === 'POST') {
    const email = String(body.email || '').trim().toLowerCase();
    const user = state.users.find((item) => item.email === email && item.role === body.role);
    if (!user || await passwordDigest(String(body.password || ''), user.salt) !== user.passwordHash) throw new Error('Email or password is incorrect. Create an account if you are new.');
    if (user.role === 'admin' && body.pin !== PIN) throw new Error('Administrator PIN is incorrect.');
    const token = createToken(user);
    log('auth', `${email} signed in`);
    persist();
    return { token, user: publicUser(user) };
  }

  if (path === '/auth/me') {
    const user = activeUser();
    if (!user) throw new Error('Your session expired. Please sign in again.');
    return publicUser(user);
  }
  if (path === '/auth/logout' && method === 'POST') { setToken(null); return { ok: true }; }
  if (path.startsWith('/auth/')) throw new Error('Unsupported account action.');

  const user = activeUser();
  if (!user) throw new Error('Sign in to continue.');
  if (method === 'POST' && ['/areas', '/requests', '/tankers', '/allocation/run', '/demo/reset'].includes(path)) requireAdmin();
  if ((method === 'PUT' || method === 'DELETE') && /^\/(areas|requests|tankers)\//.test(path)) requireAdmin();
  if (method === 'PUT' && path === '/settings') requireAdmin();

  if (path === '/areas' && method === 'GET') return [...state.areas];
  if (path === '/requests' && method === 'GET') return enrichedRequests();
  if (path === '/tankers' && method === 'GET') return [...state.tankers];
  if (path === '/activity' && method === 'GET') return state.activities.slice(0, 50);
  if (path === '/dashboard/stats' && method === 'GET') return dashboardStats();
  if (path === '/dashboard/analytics' && method === 'GET') return analytics();
  if (path === '/allocation/compare' && method === 'GET') return comparison();
  if (path === '/allocation/results' && method === 'GET') return [...state.allocations].reverse();
  if (path === '/routes/network' && method === 'GET') return { nodes, edges, depot: state.settings.depot_node || 'anna' };
  if (path === '/tracking/active' && method === 'GET') return state.deliveries.filter((item) => ['Pending', 'In Transit', 'Paused'].includes(item.simulation_status)).map((item) => ({ ...item, simulation_status: item.simulation_status, area_name: areaById(state.requests.find((request) => request.id === item.request_id)?.area_id)?.name || 'Service area', area_road_node: areaById(state.requests.find((request) => request.id === item.request_id)?.area_id)?.road_node || 'anna', vehicle: state.tankers.find((tanker) => tanker.id === item.tanker_id)?.vehicle || 'Tanker', size: state.tankers.find((tanker) => tanker.id === item.tanker_id)?.size || 'Small', current_water: state.tankers.find((tanker) => tanker.id === item.tanker_id)?.current_water || 0 }));
  if (path === '/settings' && method === 'GET') return Object.entries(state.settings).map(([key, value]) => ({ key, value: String(value) }));
  if (path === '/settings' && method === 'PUT') { state.settings = { ...state.settings, ...body }; persist(); return { ok: true }; }
  if (path === '/reports/export' && method === 'GET') return makeCsv();
  if (path === '/reports/summary' && method === 'GET') return { requests: enrichedRequests(), tankers: state.tankers, allocations: state.allocations, deliveries: state.deliveries, stats: { total_requests: state.requests.length, total_demand: dashboardStats().water_demanded, total_delivered: dashboardStats().water_delivered, unmet_demand: dashboardStats().unmet_demand, average_wait_hours: 0 } };
  if (path === '/demo/reset' && method === 'POST') {
    state = { ...initialData(), users: state.users, settings: state.settings };
    log('system', 'Operational demonstration data restored');
    persist();
    return { ok: true, message: 'Operational data restored; accounts preserved' };
  }

  const match = path.match(/^\/(areas|requests|tankers)\/(\d+)$/);
  if (match && method === 'DELETE') {
    const collection = match[1]; const id = Number(match[2]);
    if (collection === 'areas') state.areas = state.areas.filter((item) => item.id !== id);
    if (collection === 'tankers') state.tankers = state.tankers.filter((item) => item.id !== id);
    if (collection === 'requests') state.requests = state.requests.filter((item) => item.id !== id);
    persist(); return { ok: true };
  }
  if (match && method === 'PUT') {
    const collection = match[1]; const id = Number(match[2]);
    const rows = collection === 'areas' ? state.areas : collection === 'tankers' ? state.tankers : state.requests;
    const record = rows.find((item) => item.id === id);
    if (!record) throw new Error('Record not found.');
    Object.assign(record, body); persist(); return record;
  }

  if (path === '/areas' && method === 'POST') {
    if (!body.name || !body.type || !body.location) throw new Error('Complete all required service area fields.');
    const record = { id: nextNode('areas'), ...body, created_at: new Date().toISOString() };
    state.areas.push(record); log('area', `Area registered: ${record.name}`); persist(); return record;
  }
  if (path === '/requests' && method === 'POST') {
    const area = areaById(body.area_id);
    const amount = Number(body.requested_litres);
    if (!area || !Number.isFinite(amount) || amount <= 0) throw new Error('Choose an existing area and enter a quantity greater than zero.');
    const record = { id: nextNode('requests'), area_id: Number(body.area_id), requested_litres: amount, remaining_litres: amount, delivered_litres: 0, urgency: body.urgency || 'Normal', vulnerability: Number(body.vulnerability ?? area.vulnerability), created_at: new Date().toISOString(), remarks: body.remarks || '', status: 'Pending' };
    state.requests.push(record); log('request', record.urgency === 'Critical' ? 'Critical request registered' : 'New water request registered'); persist(); return record;
  }
  if (path === '/tankers' && method === 'POST') {
    const capacity = body.size === 'Large' ? 12000 : 6000;
    const record = { id: nextNode('tankers'), vehicle: body.vehicle, size: body.size || 'Small', capacity, current_water: Math.min(capacity, Number(body.current_water ?? capacity)), driver: body.driver, contact: body.contact, status: 'Available', road_node: body.road_node || 'anna', assigned_area_id: null };
    state.tankers.push(record); log('tanker', `Tanker registered: ${record.vehicle}`); persist(); return record;
  }
  if (path === '/allocation/run' && method === 'POST') {
    const strategy = body.strategy || 'FAIRNESS-FIRST';
    if (!['FCFS', 'NEAREST-FIRST', 'FAIRNESS-FIRST'].includes(strategy)) throw new Error('Unknown allocation strategy.');
    const weights = [body.weight_waiting, body.weight_demand, body.weight_vulnerability, body.weight_urgency].map(Number);
    if (weights.some((weight) => !Number.isFinite(weight) || weight < 0) || Math.abs(weights.reduce((a, b) => a + b, 0) - 1) > .001) throw new Error('Fairness weights must be non-negative and add up to 1.');
    const eligible = enrichedRequests().filter((item) => ['Pending', 'Partially Delivered'].includes(item.status) && item.remaining_litres > 0);
    const maxWait = Math.max(1, ...eligible.map((item) => (Date.now() - new Date(item.created_at).getTime()) / 3600000));
    const maxDemand = Math.max(1, ...eligible.map((item) => item.remaining_litres));
    const urgencyValues = { Normal: .25, Medium: .5, High: .75, Critical: 1 };
    const contributionById = new Map();
    for (const item of eligible) {
      const parts = {
        waiting_contribution: weights[0] * Math.min(1, (Date.now() - new Date(item.created_at).getTime()) / 3600000 / maxWait),
        unmet_contribution: weights[1] * Math.min(1, item.remaining_litres / maxDemand),
        vulnerability_contribution: weights[2] * Math.min(1, Math.max(0, Number(item.vulnerability))),
        urgency_contribution: weights[3] * (urgencyValues[item.urgency] || .25),
      };
      contributionById.set(item.id, parts);
      item.priority_score = Object.values(parts).reduce((sum, part) => sum + part, 0);
      item.distance_km = route(state.settings.depot_node || 'anna', item.road_node).distance_km;
    }
    if (strategy === 'NEAREST-FIRST') eligible.sort((a, b) => a.distance_km - b.distance_km);
    else if (strategy === 'FAIRNESS-FIRST') eligible.sort((a, b) => b.priority_score - a.priority_score);
    const rankings = eligible.map((item, index) => ({ rank: index + 1, request_id: item.id, area_name: item.area_name, score: item.priority_score || 0, ...(contributionById.get(item.id) || {}) }));
    const assignments = [];
    const tankers = state.tankers.filter((item) => item.status === 'Available' && item.current_water > 0);
    for (const request of eligible) {
      let tanker;
      if (strategy === 'NEAREST-FIRST') tanker = tankers.filter((item) => item.current_water > 0).sort((a, b) => route(a.road_node, request.road_node).distance_km - route(b.road_node, request.road_node).distance_km)[0];
      else tanker = tankers.find((item) => item.current_water > 0);
      if (!tanker) continue;
      const amount = Math.min(request.remaining_litres, tanker.current_water);
      const calculatedRoute = route(tanker.road_node, request.road_node);
      const id = nextNode('deliveries');
      const allocation = { id: nextNode('allocations'), request_id: request.id, tanker_id: tanker.id, amount_litres: amount, strategy, priority_score: request.priority_score || 0, created_at: new Date().toISOString(), delivery_id: id, distance_km: calculatedRoute.distance_km };
      state.allocations.push(allocation);
      state.deliveries.push({ id, allocation_id: allocation.id, request_id: request.id, tanker_id: tanker.id, amount_litres: amount, distance_km: calculatedRoute.distance_km, route_json: JSON.stringify(calculatedRoute.nodes), status: 'Pending', simulation_status: 'Pending', progress: 0, created_at: allocation.created_at, last_tick: Date.now() });
      const savedRequest = state.requests.find((item) => item.id === request.id);
      if (savedRequest) savedRequest.status = 'Allocated';
      tanker.status = 'Assigned';
      tanker.assigned_area_id = request.area_id;
      tanker.current_water -= amount;
      assignments.push({ rank: rankings.find((rank) => rank.request_id === request.id)?.rank || assignments.length + 1, request_id: request.id, area_name: request.area_name, tanker_id: tanker.id, amount_litres: amount, priority_score: allocation.priority_score, distance_km: calculatedRoute.distance_km, delivery_id: id, route: calculatedRoute.nodes });
    }
    if (eligible.length > assignments.length) log('allocation', `${eligible.length - assignments.length} request(s) remain unassigned due to available capacity`);
    log('allocation', `${strategy} allocation created ${assignments.length} delivery assignment(s)`);
    persist();
    return { strategy, assignments, rankings };
  }
  if (path.startsWith('/tracking/') && method === 'POST') {
    const action = path.split('/').pop();
    const delivery = state.deliveries.find((item) => item.id === Number(body.delivery_id));
    if (!delivery) throw new Error('Delivery was not found.');
    if (action === 'start' || action === 'resume') {
      delivery.simulation_status = 'In Transit'; delivery.status = 'In Transit'; delivery.last_tick = Date.now();
      const tanker = state.tankers.find((item) => item.id === delivery.tanker_id); if (tanker) tanker.status = 'In Transit';
      log('delivery', `Delivery #${delivery.id} started`);
    } else if (action === 'pause') { delivery.simulation_status = 'Paused'; delivery.status = 'Paused'; }
    else if (action === 'complete') { delivery.progress = 1; delivery.simulation_status = 'In Transit'; delivery.status = 'In Transit'; delivery.last_tick = 0; }
    else throw new Error('Unsupported tracking action.');
    touchDeliveries(); persist(); return { ok: true, delivery_id: delivery.id };
  }

  throw new Error(`Unsupported local operation: ${method} ${path}`);
}
